import { useState, useRef, useEffect } from "react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { FileSignature, Download } from "lucide-react";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import dojLogo from "@/assets/doj-logo.png";
import dojSeal from "@/assets/doj-seal.png";
import { useAuth } from "@/hooks/useAuth";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";

const templateTypes = ["تقرير", "مذكرة", "استدعاء", "خطاب", "محضر"];

const prefixMap: Record<string, string> = {
  "تقرير": "TQ", "مذكرة": "MZ", "استدعاء": "ST", "خطاب": "KH", "محضر": "MH",
};

export default function TemplatesPage() {
  const { canManage, user, roleName } = useAuth();
  const navigate = useNavigate();
  const [selectedTemplate, setSelectedTemplate] = useState("");
  const [showPreview, setShowPreview] = useState(false);
  const [departments, setDepartments] = useState<any[]>([]);
  const [selectedDept, setSelectedDept] = useState("");
  const [signatureUrl, setSignatureUrl] = useState<string | null>(null);
  const previewRef = useRef<HTMLDivElement>(null);
  const [content, setContent] = useState({
    to: "", from: "", body: "", date: new Date().toISOString().split("T")[0],
  });

  const refNumber = `${prefixMap[selectedTemplate] || "XX"}-${new Date().getFullYear()}-${String(Math.floor(Math.random() * 999) + 1).padStart(3, "0")}`;
  const userName = user?.user_metadata?.full_name || user?.email || "";

  useEffect(() => {
    supabase.from("departments").select("id, name").then(({ data }) => setDepartments(data || []));
    // Fetch current user's signature from staff table
    if (user?.email) {
      supabase.from("staff").select("signature_url").ilike("email", user.email).maybeSingle()
        .then(({ data }) => { if (data?.signature_url) setSignatureUrl(data.signature_url); });
    }
  }, [user]);

  const handleGenerate = async () => {
    if (!selectedTemplate || !content.body) {
      toast.error("يرجى تعبئة جميع الحقول المطلوبة"); return;
    }
    setShowPreview(true);
  };

  const handleSave = async () => {
    const { error } = await supabase.from("archives").insert({
      type: selectedTemplate, title: `${selectedTemplate}: ${content.to || "بدون عنوان"}`,
      from_entity: content.from, to_entity: content.to, body: content.body,
      date: content.date, reference: refNumber,
      department_id: selectedDept || null,
    });
    if (error) { toast.error("حدث خطأ"); return; }
    toast.success("تم إنشاء النموذج وحفظه في الأرشيف ✅", {
      action: { label: "عرض الأرشيف", onClick: () => navigate("/archives") },
    });
    supabase.functions.invoke("discord-notify", {
      body: {
        type: "archives",
        data: {
          "نوع النموذج": selectedTemplate,
          "الرقم المرجعي": refNumber,
          "التاريخ": content.date,
          "من": content.from || "-",
          "إلى": content.to || "-",
          "النص": content.body,
        },
      },
    }).catch(() => {});
    setContent({ to: "", from: "", body: "", date: new Date().toISOString().split("T")[0] });
    setSelectedTemplate("");
    setSelectedDept("");
    setShowPreview(false);
  };

  const handleDownloadPDF = async () => {
    const el = previewRef.current;
    if (!el) return;
    toast.loading("جارٍ إنشاء PDF...");
    try {
      const canvas = await html2canvas(el, { scale: 2, useCORS: true, backgroundColor: "#ffffff" });
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF("p", "mm", "a4");
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
      pdf.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight);
      pdf.save(`${selectedTemplate}-${refNumber}.pdf`);
      toast.dismiss();
      toast.success("تم تحميل PDF بنجاح ✅");
    } catch {
      toast.dismiss();
      toast.error("حدث خطأ أثناء إنشاء PDF");
    }
  };

  if (!canManage) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center space-y-4">
        <div className="bg-destructive/10 p-4 rounded-full"><FileSignature className="h-10 w-10 text-destructive" /></div>
        <h2 className="font-heading text-xl font-bold">غير مصرح بالوصول</h2>
        <p className="text-muted-foreground font-heading text-sm">هذه الصفحة متاحة فقط لرتبة قاضي وأعلى</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="bg-primary/10 p-2 rounded-lg"><FileSignature className="h-6 w-6 text-primary" /></div>
        <h1 className="font-heading text-2xl font-black">النماذج</h1>
      </div>

      <div className="grid gap-3 grid-cols-2 md:grid-cols-5">
        {templateTypes.map((t, i) => (
          <button key={t} onClick={() => { setSelectedTemplate(t); setShowPreview(false); }}
            className={`glass-card rounded-xl p-4 text-center card-hover animate-fade-in transition-all ${selectedTemplate === t ? "gold-border gold-glow" : ""}`}
            style={{ animationDelay: `${i * 80}ms` }}>
            <FileSignature className={`h-7 w-7 mx-auto mb-2 ${selectedTemplate === t ? "text-primary" : "text-muted-foreground"}`} />
            <p className="font-heading text-xs font-bold">{t}</p>
          </button>
        ))}
      </div>

      {selectedTemplate && !showPreview && (
        <div className="glass-card rounded-2xl overflow-hidden gold-border animate-fade-in">
          <div className="bg-primary/10 p-4 border-b border-border/30 flex items-center gap-2">
            <FileSignature className="h-5 w-5 text-primary" />
            <h2 className="font-heading font-bold">كتابة {selectedTemplate}</h2>
          </div>
          <div className="p-6 space-y-4">
            <div className="grid gap-4 md:grid-cols-3">
              <div className="space-y-2">
                <Label className="font-heading text-xs font-bold">إلى</Label>
                <Input value={content.to} onChange={(e) => setContent({ ...content, to: e.target.value })} placeholder="الجهة المرسل إليها" className="bg-secondary/50 border-border/50" />
              </div>
              <div className="space-y-2">
                <Label className="font-heading text-xs font-bold">من</Label>
                <Input value={content.from} onChange={(e) => setContent({ ...content, from: e.target.value })} placeholder="الجهة المرسلة" className="bg-secondary/50 border-border/50" />
              </div>
              <div className="space-y-2">
                <Label className="font-heading text-xs font-bold">التاريخ</Label>
                <Input type="date" value={content.date} onChange={(e) => setContent({ ...content, date: e.target.value })} className="bg-secondary/50 border-border/50" />
              </div>
            </div>
            {departments.length > 0 && (
              <div className="space-y-2">
                <Label className="font-heading text-xs font-bold">القسم</Label>
                <Select value={selectedDept} onValueChange={setSelectedDept}>
                  <SelectTrigger className="bg-secondary/50 border-border/50"><SelectValue placeholder="اختر القسم (اختياري)" /></SelectTrigger>
                  <SelectContent>
                    {departments.map((d) => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            )}
            <div className="space-y-2">
              <Label className="font-heading text-xs font-bold">المحتوى *</Label>
              <Textarea value={content.body} onChange={(e) => setContent({ ...content, body: e.target.value })} placeholder="اكتب محتوى النموذج هنا..." rows={8} className="bg-secondary/50 border-border/50" />
            </div>
            <Button onClick={handleGenerate} className="gold-gradient text-primary-foreground font-heading font-bold hover:opacity-90 gold-glow">
              <Download className="h-4 w-4 ml-2" />معاينة النموذج
            </Button>
          </div>
        </div>
      )}

      {showPreview && (
        <div className="space-y-4 animate-fade-in">
          <div className="flex gap-2">
            <Button onClick={handleSave} className="gold-gradient text-primary-foreground font-heading font-bold hover:opacity-90 gold-glow">
              <Download className="h-4 w-4 ml-2" />حفظ في الأرشيف
            </Button>
            <Button onClick={handleDownloadPDF} variant="outline" className="font-heading font-bold border-primary/30 text-primary hover:bg-primary/10">
              <Download className="h-4 w-4 ml-2" />تحميل PDF
            </Button>
            <Button onClick={() => setShowPreview(false)} variant="ghost" className="font-heading text-muted-foreground">تعديل</Button>
          </div>

          <div ref={previewRef} className="bg-white text-black rounded-xl p-10 max-w-4xl mx-auto shadow-xl relative overflow-hidden" dir="rtl" style={{ fontFamily: "'Tajawal', sans-serif" }}>
            {/* Watermark Background */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none" style={{ zIndex: 0 }}>
              <img src={dojLogo} alt="" className="opacity-30" style={{ width: '400px', height: '400px', objectFit: 'contain' }} />
            </div>
            {/* Header */}
            <div className="relative flex items-center justify-between border-b-2 border-black pb-5 mb-8 bg-black -mx-10 -mt-10 px-10 pt-10 pb-5 rounded-t-xl" style={{ zIndex: 1 }}>
              <div className="text-center flex-1">
                <p className="text-sm text-gray-300 mb-1">بسم الله الرحمن الرحيم</p>
                <h1 className="text-2xl font-black text-white">وزارة العدل</h1>
                <p className="text-sm text-gray-400 tracking-widest">Department of Justice</p>
              </div>
              <img src={dojLogo} alt="DOJ" width={80} height={80} className="rounded-full" />
            </div>

            {/* Meta */}
            <div className="flex justify-between text-sm text-gray-600 mb-8">
              <div>
                <p className="text-base"><span className="font-bold text-gray-800">الرقم المرجعي:</span> {refNumber}</p>
                <p className="text-base"><span className="font-bold text-gray-800">التاريخ:</span> {content.date}</p>
              </div>
              <div className="text-left">
                <p className="px-4 py-1.5 bg-amber-50 border border-amber-200 rounded-lg font-bold text-amber-800 text-base">{selectedTemplate}</p>
              </div>
            </div>

            {/* To/From */}
            {content.to && <p className="text-base mb-2"><span className="font-bold">إلى:</span> {content.to}</p>}
            {content.from && <p className="text-base mb-5"><span className="font-bold">من:</span> {content.from}</p>}

            {/* Body */}
            <div className="text-base leading-9 whitespace-pre-wrap mb-10 min-h-[200px]">
              {content.body}
            </div>

            {/* Signature - auto-filled with user info + signature image */}
            <div className="border-t border-gray-200 pt-6 mt-10">
              <div className="flex justify-between text-sm text-gray-500">
                <div>
                  <p className="font-bold text-gray-700 mb-1 text-base">التوقيع</p>
                  {signatureUrl ? (
                    <img src={signatureUrl} alt="التوقيع" className="h-20 object-contain mb-2" />
                  ) : (
                    <p className="text-lg">__________________________</p>
                  )}
                  <p className="mt-2 text-base">الاسم: <span className="font-bold text-gray-800">{userName}</span></p>
                  <p className="text-base">المنصب: <span className="font-bold text-gray-800">{roleName}</span></p>
                </div>
                <div className="text-left">
                  <p className="font-bold text-gray-700 mb-1 text-base">الختم الرسمي</p>
                  <img src={dojSeal} alt="الختم الرسمي" className="w-28 h-28 opacity-80" />
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="border-t border-amber-200 mt-8 pt-4 text-center text-xs text-gray-400">
              وزارة العدل — Department of Justice — وثيقة رسمية — {refNumber}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
