
-- Drop and recreate the management policy with proper WITH CHECK
DROP POLICY IF EXISTS "Judges+ can manage announcements" ON public.announcements;

CREATE POLICY "Judges+ can manage announcements"
ON public.announcements
FOR ALL
TO authenticated
USING (
  has_role(auth.uid(), 'attorney_general'::app_role)
  OR has_role(auth.uid(), 'deputy_attorney_general'::app_role)
  OR has_role(auth.uid(), 'judge'::app_role)
)
WITH CHECK (
  has_role(auth.uid(), 'attorney_general'::app_role)
  OR has_role(auth.uid(), 'deputy_attorney_general'::app_role)
  OR has_role(auth.uid(), 'judge'::app_role)
);

-- Fix same issue on other tables that use ALL without WITH CHECK
DROP POLICY IF EXISTS "Judges+ can manage departments" ON public.departments;
CREATE POLICY "Judges+ can manage departments"
ON public.departments
FOR ALL
TO authenticated
USING (
  has_role(auth.uid(), 'attorney_general'::app_role)
  OR has_role(auth.uid(), 'deputy_attorney_general'::app_role)
  OR has_role(auth.uid(), 'judge'::app_role)
)
WITH CHECK (
  has_role(auth.uid(), 'attorney_general'::app_role)
  OR has_role(auth.uid(), 'deputy_attorney_general'::app_role)
  OR has_role(auth.uid(), 'judge'::app_role)
);

DROP POLICY IF EXISTS "Judges+ can manage archives" ON public.archives;
CREATE POLICY "Judges+ can manage archives"
ON public.archives
FOR ALL
TO authenticated
USING (
  has_role(auth.uid(), 'attorney_general'::app_role)
  OR has_role(auth.uid(), 'deputy_attorney_general'::app_role)
  OR has_role(auth.uid(), 'judge'::app_role)
)
WITH CHECK (
  has_role(auth.uid(), 'attorney_general'::app_role)
  OR has_role(auth.uid(), 'deputy_attorney_general'::app_role)
  OR has_role(auth.uid(), 'judge'::app_role)
);

DROP POLICY IF EXISTS "Judges+ can manage staff" ON public.staff;
CREATE POLICY "Judges+ can manage staff"
ON public.staff
FOR ALL
TO authenticated
USING (
  has_role(auth.uid(), 'attorney_general'::app_role)
  OR has_role(auth.uid(), 'deputy_attorney_general'::app_role)
  OR has_role(auth.uid(), 'judge'::app_role)
)
WITH CHECK (
  has_role(auth.uid(), 'attorney_general'::app_role)
  OR has_role(auth.uid(), 'deputy_attorney_general'::app_role)
  OR has_role(auth.uid(), 'judge'::app_role)
);
