import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Archive, FileText, Calendar, Hash, Lock } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";

export default function ArchivesPage() {
  const [archives, setArchives] = useState<any[]>([]);
  const [departments, setDepartments] = useState<any[]>([]);
  const [deptFilter, setDeptFilter] = useState("الكل");
  const [expanded, setExpanded] = useState<string | null>(null);
  const { canManage, role, userDepartments } = useAuth();

  const canSeeAll = role === "attorney_general" || role === "deputy_attorney_general";

  useEffect(() => {
    supabase.from("departments").select("id, name").then(({ data }) => setDepartments(data || []));
    supabase.from("archives").select("*").order("created_at", { ascending: false })
      .then(({ data }) => setArchives(data || []));
  }, []);

  const deptName = (id: string) => departments.find((d) => d.id === id)?.name || "";

  if (!canManage) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center space-y-4">
        <div className="bg-destructive/10 p-4 rounded-full"><Lock className="h-10 w-10 text-destructive" /></div>
        <h2 className="font-heading text-xl font-bold">غير مصرح بالوصول</h2>
        <p className="text-muted-foreground font-heading text-sm">هذه الصفحة متاحة فقط لرتبة قاضي وأعلى</p>
      </div>
    );
  }

  let filtered = archives;
  if (!canSeeAll && userDepartments.length > 0) {
    filtered = filtered.filter((a) => !a.department_id || userDepartments.includes(a.department_id));
  }
  if (deptFilter !== "الكل") filtered = filtered.filter((a) => a.department_id === deptFilter);

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="bg-primary/10 p-2 rounded-lg"><Archive className="h-6 w-6 text-primary" /></div>
        <h1 className="font-heading text-2xl font-black">الأرشيفات</h1>
      </div>

      {departments.length > 0 && (
        <div className="flex flex-wrap gap-2">
          <button onClick={() => setDeptFilter("الكل")} className={`px-3 py-1.5 rounded-lg text-[10px] font-heading font-bold transition-all ${deptFilter === "الكل" ? "bg-primary/20 text-primary" : "glass-card text-muted-foreground hover:text-foreground"}`}>
            جميع الأقسام
          </button>
          {departments.map((d) => (
            <button key={d.id} onClick={() => setDeptFilter(d.id)} className={`px-3 py-1.5 rounded-lg text-[10px] font-heading font-bold transition-all ${deptFilter === d.id ? "bg-primary/20 text-primary" : "glass-card text-muted-foreground hover:text-foreground"}`}>
              {d.name}
            </button>
          ))}
        </div>
      )}

      {filtered.length === 0 ? (
        <div className="glass-card rounded-xl p-12 text-center">
          <Archive className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
          <p className="text-muted-foreground font-heading">لا توجد أرشيفات</p>
        </div>
      ) : (
        <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((a, i) => (
            <div key={a.id} onClick={() => setExpanded(expanded === a.id ? null : a.id)} className="glass-card rounded-xl overflow-hidden card-hover cursor-pointer animate-fade-in" style={{ animationDelay: `${i * 60}ms` }}>
              <div className="bg-primary/10 p-4 border-b border-border/20 flex items-center gap-3">
                <div className="bg-primary/20 p-2 rounded-lg"><FileText className="h-5 w-5 text-primary" /></div>
                <span className="px-2 py-0.5 text-[10px] rounded-full gold-gradient text-primary-foreground font-heading font-bold">{a.type}</span>
                {a.department_id && <span className="px-2 py-0.5 text-[10px] rounded-full bg-amber-500/15 text-amber-400 font-heading">{deptName(a.department_id)}</span>}
              </div>
              <div className="p-4 space-y-3">
                <h3 className="font-heading font-bold text-sm leading-relaxed">{a.title}</h3>
                <div className="flex items-center gap-4 text-[11px] text-muted-foreground">
                  <span className="flex items-center gap-1"><Hash className="h-3 w-3" /><span className="font-mono">{a.reference}</span></span>
                  <span className="flex items-center gap-1"><Calendar className="h-3 w-3" />{a.date}</span>
                </div>
                {expanded === a.id && (a.to_entity || a.from_entity || a.body) && (
                  <div className="pt-3 border-t border-border/20 space-y-2 text-xs animate-fade-in">
                    {a.from_entity && <p><span className="font-heading font-bold text-primary">من:</span> {a.from_entity}</p>}
                    {a.to_entity && <p><span className="font-heading font-bold text-primary">إلى:</span> {a.to_entity}</p>}
                    {a.body && <p className="text-muted-foreground whitespace-pre-wrap leading-relaxed">{a.body}</p>}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
