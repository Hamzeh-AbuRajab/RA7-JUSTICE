import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Megaphone, ChevronDown } from "lucide-react";

const types = ["الكل", "إعلان", "استدعاء", "تعميم", "قرار"];

export default function AnnouncementsPage() {
  const { role, userDepartments } = useAuth();
  const [filter, setFilter] = useState("الكل");
  const [announcements, setAnnouncements] = useState<any[]>([]);
  const [departments, setDepartments] = useState<any[]>([]);
  const [deptFilter, setDeptFilter] = useState("الكل");
  const [openId, setOpenId] = useState<string | null>(null);

  const canSeeAll = role === "attorney_general" || role === "deputy_attorney_general";

  useEffect(() => {
    supabase.from("departments").select("id, name").then(({ data }) => setDepartments(data || []));
    supabase.from("announcements").select("*").order("created_at", { ascending: false })
      .then(({ data }) => setAnnouncements(data || []));
  }, []);

  const deptName = (id: string) => departments.find((d) => d.id === id)?.name || "";

  let filtered = announcements;
  // Filter by department access
  if (!canSeeAll && userDepartments.length > 0) {
    filtered = filtered.filter((a) => !a.department_id || userDepartments.includes(a.department_id));
  }
  if (filter !== "الكل") filtered = filtered.filter((a) => a.type === filter);
  if (deptFilter !== "الكل") filtered = filtered.filter((a) => a.department_id === deptFilter);

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="bg-primary/10 p-2 rounded-lg"><Megaphone className="h-6 w-6 text-primary" /></div>
        <h1 className="font-heading text-2xl font-black">الإعلانات والاستدعاءات</h1>
      </div>

      <div className="flex flex-wrap gap-2">
        {types.map((t) => (
          <button key={t} onClick={() => setFilter(t)} className={`px-4 py-2 rounded-lg text-xs font-heading font-bold transition-all duration-200 ${filter === t ? "gold-gradient text-primary-foreground gold-glow" : "glass-card text-muted-foreground hover:text-foreground"}`}>
            {t}
          </button>
        ))}
      </div>

      {departments.length > 0 && (
        <div className="flex flex-wrap gap-2">
          <button onClick={() => setDeptFilter("الكل")} className={`px-3 py-1.5 rounded-lg text-[10px] font-heading font-bold transition-all ${deptFilter === "الكل" ? "bg-primary/20 text-primary" : "glass-card text-muted-foreground hover:text-foreground"}`}>
            جميع الأقسام
          </button>
          {departments.map((d) => (
            <button key={d.id} onClick={() => setDeptFilter(d.id)} className={`px-3 py-1.5 rounded-lg text-[10px] font-heading font-bold transition-all ${deptFilter === d.id ? "bg-primary/20 text-primary" : "glass-card text-muted-foreground hover:text-foreground"}`}>
              {d.name}
            </button>
          ))}
        </div>
      )}

      {filtered.length === 0 ? (
        <div className="glass-card rounded-xl p-12 text-center">
          <Megaphone className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
          <p className="text-muted-foreground font-heading">لا توجد إعلانات</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((a, i) => {
            const isOpen = openId === a.id;
            return (
              <div key={a.id} onClick={() => setOpenId(isOpen ? null : a.id)}
                className="glass-card rounded-xl card-hover animate-fade-in cursor-pointer flex flex-col transition-all duration-300"
                style={{ animationDelay: `${i * 60}ms` }}>
                <div className="p-5 flex flex-col items-center text-center gap-3">
                  <div className="bg-primary/10 p-3 rounded-xl">
                    <Megaphone className="h-6 w-6 text-primary" />
                  </div>
                  <span className="px-3 py-1 text-[10px] rounded-full bg-primary/15 text-primary font-heading font-bold">{a.type}</span>
                  {a.department_id && <span className="px-2 py-0.5 text-[10px] rounded-full bg-amber-500/15 text-amber-400 font-heading">{deptName(a.department_id)}</span>}
                  <h3 className="font-heading font-bold text-sm">{a.title}</h3>
                  <span className="text-[10px] text-muted-foreground">{a.date}</span>
                  <ChevronDown className={`h-4 w-4 text-muted-foreground transition-transform duration-300 ${isOpen ? "rotate-180" : ""}`} />
                </div>
                <div className={`overflow-hidden transition-all duration-300 ${isOpen ? "max-h-96 opacity-100" : "max-h-0 opacity-0"}`}>
                  <div className="px-5 pb-5 border-t border-border/30 pt-4">
                    <p className="text-xs text-muted-foreground leading-relaxed whitespace-pre-wrap">{a.content}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
