import { Shield, Building2, Scale, Gavel, LucideIcon } from "lucide-react";

export const departmentIcons: Record<string, LucideIcon> = {
  Shield,
  Building2,
  Scale,
  Gavel,
};
