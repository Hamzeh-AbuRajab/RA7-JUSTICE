
-- Create private schema not exposed by PostgREST
CREATE SCHEMA IF NOT EXISTS private;
REVOKE ALL ON SCHEMA private FROM PUBLIC, anon, authenticated;
GRANT USAGE ON SCHEMA private TO postgres, service_role;

-- Recreate has_role in private
CREATE OR REPLACE FUNCTION private.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role
  )
$$;
REVOKE ALL ON FUNCTION private.has_role(uuid, public.app_role) FROM PUBLIC;
-- RLS policy execution runs with the querying role; grant execute to those roles.
GRANT EXECUTE ON FUNCTION private.has_role(uuid, public.app_role) TO authenticated, anon, service_role;

-- Rewrite every RLS policy that referenced public.has_role to use private.has_role

-- user_roles
DROP POLICY IF EXISTS "Attorney General can manage roles" ON public.user_roles;
CREATE POLICY "Attorney General can manage roles" ON public.user_roles
  FOR ALL TO authenticated
  USING (private.has_role(auth.uid(), 'attorney_general'::app_role))
  WITH CHECK (private.has_role(auth.uid(), 'attorney_general'::app_role));

-- user_departments
DROP POLICY IF EXISTS "AG can manage user_departments" ON public.user_departments;
CREATE POLICY "AG can manage user_departments" ON public.user_departments
  FOR ALL TO authenticated
  USING (private.has_role(auth.uid(), 'attorney_general'::app_role))
  WITH CHECK (private.has_role(auth.uid(), 'attorney_general'::app_role));

DROP POLICY IF EXISTS "Deputy AG can view user_departments" ON public.user_departments;
CREATE POLICY "Deputy AG can view user_departments" ON public.user_departments
  FOR SELECT TO authenticated
  USING (private.has_role(auth.uid(), 'deputy_attorney_general'::app_role));

-- staff
DROP POLICY IF EXISTS "Judges+ can manage staff" ON public.staff;
CREATE POLICY "Judges+ can manage staff" ON public.staff
  FOR ALL TO authenticated
  USING (private.has_role(auth.uid(),'attorney_general'::app_role) OR private.has_role(auth.uid(),'deputy_attorney_general'::app_role) OR private.has_role(auth.uid(),'judge'::app_role))
  WITH CHECK (private.has_role(auth.uid(),'attorney_general'::app_role) OR private.has_role(auth.uid(),'deputy_attorney_general'::app_role) OR private.has_role(auth.uid(),'judge'::app_role));

DROP POLICY IF EXISTS "Judges+ or self can view staff" ON public.staff;
CREATE POLICY "Judges+ or self can view staff" ON public.staff
  FOR SELECT TO authenticated
  USING (
    private.has_role(auth.uid(),'attorney_general'::app_role)
    OR private.has_role(auth.uid(),'deputy_attorney_general'::app_role)
    OR private.has_role(auth.uid(),'judge'::app_role)
    OR lower(email) = lower((SELECT au.email FROM auth.users au WHERE au.id = auth.uid()))
  );

-- announcements
DROP POLICY IF EXISTS "Judges+ can manage announcements" ON public.announcements;
CREATE POLICY "Judges+ can manage announcements" ON public.announcements
  FOR ALL TO authenticated
  USING (private.has_role(auth.uid(),'attorney_general'::app_role) OR private.has_role(auth.uid(),'deputy_attorney_general'::app_role) OR private.has_role(auth.uid(),'judge'::app_role))
  WITH CHECK (private.has_role(auth.uid(),'attorney_general'::app_role) OR private.has_role(auth.uid(),'deputy_attorney_general'::app_role) OR private.has_role(auth.uid(),'judge'::app_role));

-- departments
DROP POLICY IF EXISTS "Judges+ can manage departments" ON public.departments;
CREATE POLICY "Judges+ can manage departments" ON public.departments
  FOR ALL TO authenticated
  USING (private.has_role(auth.uid(),'attorney_general'::app_role) OR private.has_role(auth.uid(),'deputy_attorney_general'::app_role) OR private.has_role(auth.uid(),'judge'::app_role))
  WITH CHECK (private.has_role(auth.uid(),'attorney_general'::app_role) OR private.has_role(auth.uid(),'deputy_attorney_general'::app_role) OR private.has_role(auth.uid(),'judge'::app_role));

-- archives
DROP POLICY IF EXISTS "Judges+ can manage archives" ON public.archives;
CREATE POLICY "Judges+ can manage archives" ON public.archives
  FOR ALL TO authenticated
  USING (private.has_role(auth.uid(),'attorney_general'::app_role) OR private.has_role(auth.uid(),'deputy_attorney_general'::app_role) OR private.has_role(auth.uid(),'judge'::app_role))
  WITH CHECK (private.has_role(auth.uid(),'attorney_general'::app_role) OR private.has_role(auth.uid(),'deputy_attorney_general'::app_role) OR private.has_role(auth.uid(),'judge'::app_role));

DROP POLICY IF EXISTS "Judges+ can view archives" ON public.archives;
CREATE POLICY "Judges+ can view archives" ON public.archives
  FOR SELECT TO authenticated
  USING (private.has_role(auth.uid(),'attorney_general'::app_role) OR private.has_role(auth.uid(),'deputy_attorney_general'::app_role) OR private.has_role(auth.uid(),'judge'::app_role));

-- applications
DROP POLICY IF EXISTS "Authenticated can view applications" ON public.applications;
CREATE POLICY "Authenticated can view applications" ON public.applications
  FOR SELECT TO authenticated
  USING (private.has_role(auth.uid(),'attorney_general'::app_role) OR private.has_role(auth.uid(),'deputy_attorney_general'::app_role) OR private.has_role(auth.uid(),'judge'::app_role));

DROP POLICY IF EXISTS "Judges+ can delete applications" ON public.applications;
CREATE POLICY "Judges+ can delete applications" ON public.applications
  FOR DELETE TO authenticated
  USING (private.has_role(auth.uid(),'judge'::app_role) OR private.has_role(auth.uid(),'deputy_attorney_general'::app_role) OR private.has_role(auth.uid(),'attorney_general'::app_role));

DROP POLICY IF EXISTS "Judges+ can update applications" ON public.applications;
CREATE POLICY "Judges+ can update applications" ON public.applications
  FOR UPDATE TO authenticated
  USING (private.has_role(auth.uid(),'attorney_general'::app_role) OR private.has_role(auth.uid(),'deputy_attorney_general'::app_role) OR private.has_role(auth.uid(),'judge'::app_role));

-- session_requests
DROP POLICY IF EXISTS "Authenticated can view session requests" ON public.session_requests;
CREATE POLICY "Authenticated can view session requests" ON public.session_requests
  FOR SELECT TO authenticated
  USING (private.has_role(auth.uid(),'attorney_general'::app_role) OR private.has_role(auth.uid(),'deputy_attorney_general'::app_role) OR private.has_role(auth.uid(),'judge'::app_role));

DROP POLICY IF EXISTS "Judges+ can delete session requests" ON public.session_requests;
CREATE POLICY "Judges+ can delete session requests" ON public.session_requests
  FOR DELETE TO authenticated
  USING (private.has_role(auth.uid(),'judge'::app_role) OR private.has_role(auth.uid(),'deputy_attorney_general'::app_role) OR private.has_role(auth.uid(),'attorney_general'::app_role));

DROP POLICY IF EXISTS "Judges+ can update session requests" ON public.session_requests;
CREATE POLICY "Judges+ can update session requests" ON public.session_requests
  FOR UPDATE TO authenticated
  USING (private.has_role(auth.uid(),'attorney_general'::app_role) OR private.has_role(auth.uid(),'deputy_attorney_general'::app_role) OR private.has_role(auth.uid(),'judge'::app_role));

-- budget_items
DROP POLICY IF EXISTS "AG and Deputy can delete budget" ON public.budget_items;
CREATE POLICY "AG and Deputy can delete budget" ON public.budget_items
  FOR DELETE TO authenticated
  USING (private.has_role(auth.uid(),'attorney_general'::app_role) OR private.has_role(auth.uid(),'deputy_attorney_general'::app_role));

DROP POLICY IF EXISTS "AG and Deputy can insert budget" ON public.budget_items;
CREATE POLICY "AG and Deputy can insert budget" ON public.budget_items
  FOR INSERT TO authenticated
  WITH CHECK (private.has_role(auth.uid(),'attorney_general'::app_role) OR private.has_role(auth.uid(),'deputy_attorney_general'::app_role));

DROP POLICY IF EXISTS "AG and Deputy can update budget" ON public.budget_items;
CREATE POLICY "AG and Deputy can update budget" ON public.budget_items
  FOR UPDATE TO authenticated
  USING (private.has_role(auth.uid(),'attorney_general'::app_role) OR private.has_role(auth.uid(),'deputy_attorney_general'::app_role));

DROP POLICY IF EXISTS "AG and Deputy can view budget" ON public.budget_items;
CREATE POLICY "AG and Deputy can view budget" ON public.budget_items
  FOR SELECT TO authenticated
  USING (private.has_role(auth.uid(),'attorney_general'::app_role) OR private.has_role(auth.uid(),'deputy_attorney_general'::app_role));

-- storage.objects photos policies
DROP POLICY IF EXISTS "Judges+ can delete photos" ON storage.objects;
CREATE POLICY "Judges+ can delete photos" ON storage.objects
  FOR DELETE TO authenticated
  USING (bucket_id = 'photos' AND (private.has_role(auth.uid(),'attorney_general'::app_role) OR private.has_role(auth.uid(),'deputy_attorney_general'::app_role) OR private.has_role(auth.uid(),'judge'::app_role)));

DROP POLICY IF EXISTS "Judges+ can upload photos" ON storage.objects;
CREATE POLICY "Judges+ can upload photos" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'photos' AND (private.has_role(auth.uid(),'attorney_general'::app_role) OR private.has_role(auth.uid(),'deputy_attorney_general'::app_role) OR private.has_role(auth.uid(),'judge'::app_role)));

-- Now the public.has_role in public schema can be dropped
DROP FUNCTION IF EXISTS public.has_role(uuid, public.app_role);
