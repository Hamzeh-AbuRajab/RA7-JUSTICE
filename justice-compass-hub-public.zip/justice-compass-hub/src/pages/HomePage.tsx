import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Megaphone, LayoutGrid, FileText, Archive, FileSignature, Users, ChevronLeft, Gavel } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import dojLogo from "@/assets/doj-logo.png";

const quickSections = [
  { title: "الإعلانات", desc: "آخر الأخبار والاستدعاءات", icon: Megaphone, url: "/announcements" },
  { title: "الأقسام", desc: "أقسام الوزارة", icon: LayoutGrid, url: "/departments" },
  { title: "التقديم", desc: "قدّم طلبك الآن", icon: FileText, url: "/apply" },
  { title: "طلب جلسة", desc: "طلب جلسة مع القاضي", icon: Gavel, url: "/request-session" },
  { title: "الأرشيفات", desc: "الوثائق والقرارات", icon: Archive, url: "/archives" },
  { title: "النماذج", desc: "إنشاء المستندات", icon: FileSignature, url: "/templates" },
  { title: "المنسوبين", desc: "بيانات الموظفين", icon: Users, url: "/staff" },
];

export default function HomePage() {
  const [latestAnnouncements, setLatest] = useState<any[]>([]);

  useEffect(() => {
    supabase.from("announcements").select("*").order("created_at", { ascending: false }).limit(3)
      .then(({ data }) => setLatest(data || []));
  }, []);

  return (
    <div className="space-y-8">
      <div className="hero-gradient rounded-2xl p-8 md:p-12 gold-border relative overflow-hidden">
        <div className="absolute inset-0 grid-bg opacity-30" />
        <div className="relative text-center">
          <img src={dojLogo} alt="Department of Justice" width={130} height={130} className="mx-auto mb-6 drop-shadow-[0_0_20px_hsl(42,78%,50%,0.3)]" />
          <h1 className="font-heading text-3xl md:text-4xl font-black text-foreground mb-1">
            وزارة <span className="text-primary gold-text">العدل</span>
          </h1>
          <p className="text-primary/80 text-lg font-heading tracking-widest">Department of Justice</p>
        </div>
      </div>

      <div>
        <h2 className="font-heading text-xl font-bold mb-5">الوصول السريع</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {quickSections.map((s, i) => (
            <Link key={s.title} to={s.url}>
              <div className="glass-card rounded-xl p-5 card-hover cursor-pointer group animate-fade-in" style={{ animationDelay: `${i * 80}ms` }}>
                <div className="flex items-start justify-between">
                  <div className="bg-primary/10 p-2.5 rounded-lg group-hover:bg-primary/20 transition-colors">
                    <s.icon className="h-5 w-5 text-primary" />
                  </div>
                  <ChevronLeft className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
                </div>
                <h3 className="font-heading font-bold mt-3 text-sm">{s.title}</h3>
                <p className="text-xs text-muted-foreground mt-1">{s.desc}</p>
              </div>
            </Link>
          ))}
        </div>
      </div>

      {latestAnnouncements.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-5">
            <h2 className="font-heading text-xl font-bold">آخر الإعلانات</h2>
            <Link to="/announcements" className="text-xs text-primary hover:underline font-heading flex items-center gap-1">
              عرض الكل <ChevronLeft className="h-3 w-3" />
            </Link>
          </div>
          <div className="grid gap-4 md:grid-cols-3">
            {latestAnnouncements.map((a: any, i: number) => (
              <div key={a.id} className="glass-card rounded-xl p-5 card-hover animate-fade-in" style={{ animationDelay: `${i * 100}ms` }}>
                <div className="flex items-center gap-2 mb-3">
                  <span className="px-2 py-0.5 text-[10px] rounded-full bg-primary/15 text-primary font-heading font-bold">{a.type}</span>
                  <span className="text-[10px] text-muted-foreground">{a.date}</span>
                </div>
                <h3 className="font-heading font-bold text-sm mb-2">{a.title}</h3>
                <p className="text-xs text-muted-foreground line-clamp-2">{a.content}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
