CREATE TABLE public.budget_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  amount numeric(14,2) NOT NULL DEFAULT 0,
  kind text NOT NULL DEFAULT 'expense' CHECK (kind IN ('expense','revenue')),
  department_id uuid REFERENCES public.departments(id) ON DELETE SET NULL,
  fiscal_year int NOT NULL DEFAULT EXTRACT(YEAR FROM now())::int,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.budget_items TO authenticated;
GRANT ALL ON public.budget_items TO service_role;

ALTER TABLE public.budget_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated can view budget"
ON public.budget_items FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "AG and Deputy can insert budget"
ON public.budget_items FOR INSERT
TO authenticated
WITH CHECK (
  public.has_role(auth.uid(), 'attorney_general'::app_role)
  OR public.has_role(auth.uid(), 'deputy_attorney_general'::app_role)
);

CREATE POLICY "AG and Deputy can update budget"
ON public.budget_items FOR UPDATE
TO authenticated
USING (
  public.has_role(auth.uid(), 'attorney_general'::app_role)
  OR public.has_role(auth.uid(), 'deputy_attorney_general'::app_role)
);

CREATE POLICY "AG and Deputy can delete budget"
ON public.budget_items FOR DELETE
TO authenticated
USING (
  public.has_role(auth.uid(), 'attorney_general'::app_role)
  OR public.has_role(auth.uid(), 'deputy_attorney_general'::app_role)
);

CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END $$;

CREATE TRIGGER budget_items_updated_at
BEFORE UPDATE ON public.budget_items
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();