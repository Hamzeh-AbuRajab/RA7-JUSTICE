import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { ScrollText, Send } from "lucide-react";

export default function MemoPage() {
  const [form, setForm] = useState({
    fullName: "",
    nationalId: "",
    phone: "",
    targetEntity: "",
    subject: "",
    details: "",
  });
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.fullName || !form.nationalId || !form.phone || !form.targetEntity || !form.subject) {
      toast.error("يرجى تعبئة جميع الحقول المطلوبة");
      return;
    }
    setSubmitting(true);
    const { error } = await supabase.from("memo_requests").insert({
      full_name: form.fullName,
      national_id: form.nationalId,
      phone: form.phone,
      target_entity: form.targetEntity,
      subject: form.subject,
      details: form.details || null,
      status: "جديد",
    });
    setSubmitting(false);
    if (error) {
      toast.error("حدث خطأ أثناء الإرسال");
      return;
    }
    toast.success("تم إرسال طلب المذكرة بنجاح ✅");
    supabase.functions.invoke("discord-notify", {
      body: {
        type: "memo",
        data: {
          "الاسم الكامل": form.fullName,
          "اسم مستخدم Discord": form.nationalId,
          "رقم الجوال": form.phone,
          "الجهة المطلوبة": form.targetEntity,
          "موضوع المذكرة": form.subject,
          "التفاصيل": form.details || "-",
        },
      },
    }).catch(() => {});
    setForm({ fullName: "", nationalId: "", phone: "", targetEntity: "", subject: "", details: "" });
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="glass-card rounded-2xl overflow-hidden gold-border animate-fade-in">
        <div className="bg-primary/10 p-5 border-b border-border/30 flex items-center gap-3">
          <div className="bg-primary/20 p-2 rounded-lg"><ScrollText className="h-6 w-6 text-primary" /></div>
          <div>
            <h1 className="font-heading text-xl font-black">طلب مذكرة</h1>
            <p className="text-xs text-muted-foreground">قدّم طلب إصدار مذكرة رسمية</p>
          </div>
        </div>
        <div className="p-6">
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label className="font-heading text-xs font-bold">الاسم الكامل *</Label>
                <Input value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} placeholder="أدخل الاسم الكامل" className="bg-secondary/50 border-border/50" />
              </div>
              <div className="space-y-2">
                <Label className="font-heading text-xs font-bold">اسم مستخدم Discord *</Label>
                <Input value={form.nationalId} onChange={(e) => setForm({ ...form, nationalId: e.target.value })} placeholder="أدخل اسم مستخدم Discord" className="bg-secondary/50 border-border/50" />
              </div>
            </div>
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label className="font-heading text-xs font-bold">رقم الجوال *</Label>
                <Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="05XXXXXXXX" className="bg-secondary/50 border-border/50" />
              </div>
              <div className="space-y-2">
                <Label className="font-heading text-xs font-bold">الجهة المطلوبة *</Label>
                <Input value={form.targetEntity} onChange={(e) => setForm({ ...form, targetEntity: e.target.value })} placeholder="مثال: المحكمة الجزائية" className="bg-secondary/50 border-border/50" />
              </div>
            </div>
            <div className="space-y-2">
              <Label className="font-heading text-xs font-bold">موضوع المذكرة *</Label>
              <Input value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} placeholder="عنوان أو موضوع المذكرة" className="bg-secondary/50 border-border/50" />
            </div>
            <div className="space-y-2">
              <Label className="font-heading text-xs font-bold">تفاصيل إضافية</Label>
              <Textarea value={form.details} onChange={(e) => setForm({ ...form, details: e.target.value })} placeholder="اكتب تفاصيل الطلب..." rows={5} className="bg-secondary/50 border-border/50" />
            </div>
            <Button type="submit" disabled={submitting} className="w-full gold-gradient text-primary-foreground font-heading font-bold hover:opacity-90 gold-glow h-11">
              <Send className="h-4 w-4 ml-2" />{submitting ? "جاري الإرسال..." : "إرسال الطلب"}
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}
