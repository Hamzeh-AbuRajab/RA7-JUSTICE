export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.4"
  }
  public: {
    Tables: {
      announcements: {
        Row: {
          content: string
          created_at: string
          created_by: string | null
          date: string
          department_id: string | null
          id: string
          title: string
          type: string
        }
        Insert: {
          content?: string
          created_at?: string
          created_by?: string | null
          date?: string
          department_id?: string | null
          id?: string
          title: string
          type?: string
        }
        Update: {
          content?: string
          created_at?: string
          created_by?: string | null
          date?: string
          department_id?: string | null
          id?: string
          title?: string
          type?: string
        }
        Relationships: [
          {
            foreignKeyName: "announcements_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
        ]
      }
      applications: {
        Row: {
          created_at: string
          date: string
          department: string
          full_name: string
          id: string
          message: string | null
          national_id: string
          phone: string
          status: string
          type: string
        }
        Insert: {
          created_at?: string
          date?: string
          department?: string
          full_name: string
          id?: string
          message?: string | null
          national_id: string
          phone: string
          status?: string
          type?: string
        }
        Update: {
          created_at?: string
          date?: string
          department?: string
          full_name?: string
          id?: string
          message?: string | null
          national_id?: string
          phone?: string
          status?: string
          type?: string
        }
        Relationships: []
      }
      archives: {
        Row: {
          body: string | null
          created_at: string
          created_by: string | null
          date: string
          department_id: string | null
          from_entity: string | null
          id: string
          reference: string
          title: string
          to_entity: string | null
          type: string
        }
        Insert: {
          body?: string | null
          created_at?: string
          created_by?: string | null
          date?: string
          department_id?: string | null
          from_entity?: string | null
          id?: string
          reference?: string
          title: string
          to_entity?: string | null
          type?: string
        }
        Update: {
          body?: string | null
          created_at?: string
          created_by?: string | null
          date?: string
          department_id?: string | null
          from_entity?: string | null
          id?: string
          reference?: string
          title?: string
          to_entity?: string | null
          type?: string
        }
        Relationships: [
          {
            foreignKeyName: "archives_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
        ]
      }
      budget_items: {
        Row: {
          amount: number
          created_at: string
          created_by: string | null
          department_id: string | null
          description: string | null
          fiscal_year: number
          id: string
          kind: string
          title: string
          updated_at: string
        }
        Insert: {
          amount?: number
          created_at?: string
          created_by?: string | null
          department_id?: string | null
          description?: string | null
          fiscal_year?: number
          id?: string
          kind?: string
          title: string
          updated_at?: string
        }
        Update: {
          amount?: number
          created_at?: string
          created_by?: string | null
          department_id?: string | null
          description?: string | null
          fiscal_year?: number
          id?: string
          kind?: string
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "budget_items_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
        ]
      }
      commercial_license_requests: {
        Row: {
          address: string
          business_name: string
          business_type: string
          capital: string | null
          created_at: string
          date: string
          full_name: string
          id: string
          national_id: string
          notes: string | null
          phone: string
          status: string
          updated_at: string
        }
        Insert: {
          address: string
          business_name: string
          business_type: string
          capital?: string | null
          created_at?: string
          date?: string
          full_name: string
          id?: string
          national_id: string
          notes?: string | null
          phone: string
          status?: string
          updated_at?: string
        }
        Update: {
          address?: string
          business_name?: string
          business_type?: string
          capital?: string | null
          created_at?: string
          date?: string
          full_name?: string
          id?: string
          national_id?: string
          notes?: string | null
          phone?: string
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      departments: {
        Row: {
          created_at: string
          description: string
          head: string
          icon: string
          id: string
          name: string
          phone: string
        }
        Insert: {
          created_at?: string
          description?: string
          head?: string
          icon?: string
          id?: string
          name: string
          phone?: string
        }
        Update: {
          created_at?: string
          description?: string
          head?: string
          icon?: string
          id?: string
          name?: string
          phone?: string
        }
        Relationships: []
      }
      memo_requests: {
        Row: {
          created_at: string
          details: string | null
          full_name: string
          id: string
          national_id: string
          phone: string
          status: string
          subject: string
          target_entity: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          details?: string | null
          full_name: string
          id?: string
          national_id: string
          phone: string
          status?: string
          subject: string
          target_entity: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          details?: string | null
          full_name?: string
          id?: string
          national_id?: string
          phone?: string
          status?: string
          subject?: string
          target_entity?: string
          updated_at?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          full_name: string
          id: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          full_name?: string
          id: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          full_name?: string
          id?: string
        }
        Relationships: []
      }
      session_requests: {
        Row: {
          case_number: string
          created_at: string
          date: string
          full_name: string
          id: string
          national_id: string
          phone: string
          preferred_date: string
          reason: string
          status: string
        }
        Insert: {
          case_number?: string
          created_at?: string
          date?: string
          full_name: string
          id?: string
          national_id: string
          phone: string
          preferred_date?: string
          reason?: string
          status?: string
        }
        Update: {
          case_number?: string
          created_at?: string
          date?: string
          full_name?: string
          id?: string
          national_id?: string
          phone?: string
          preferred_date?: string
          reason?: string
          status?: string
        }
        Relationships: []
      }
      staff: {
        Row: {
          created_at: string
          department: string
          department_id: string | null
          email: string
          id: string
          join_date: string
          name: string
          phone: string
          photo_url: string | null
          position: string
          signature_url: string | null
        }
        Insert: {
          created_at?: string
          department?: string
          department_id?: string | null
          email?: string
          id?: string
          join_date?: string
          name: string
          phone?: string
          photo_url?: string | null
          position?: string
          signature_url?: string | null
        }
        Update: {
          created_at?: string
          department?: string
          department_id?: string | null
          email?: string
          id?: string
          join_date?: string
          name?: string
          phone?: string
          photo_url?: string | null
          position?: string
          signature_url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "staff_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
        ]
      }
      user_departments: {
        Row: {
          created_at: string
          department_id: string
          id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          department_id: string
          id?: string
          user_id: string
        }
        Update: {
          created_at?: string
          department_id?: string
          id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_departments_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      find_user_by_email: { Args: { _email: string }; Returns: string }
      get_user_email: { Args: { _user_id: string }; Returns: string }
      get_user_role: {
        Args: { _user_id: string }
        Returns: Database["public"]["Enums"]["app_role"]
      }
      user_has_department_access: {
        Args: { _department_id: string; _user_id: string }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "law" | "judge" | "attorney_general" | "deputy_attorney_general"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["law", "judge", "attorney_general", "deputy_attorney_general"],
    },
  },
} as const
