import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { toast } from "sonner";
import { Plus, Pencil, Trash2, TrendingUp, TrendingDown, Wallet, Landmark } from "lucide-react";

interface BudgetItem {
  id: string;
  title: string;
  description: string | null;
  amount: number;
  kind: "expense" | "revenue";
  department_id: string | null;
  fiscal_year: number;
}

interface Dept { id: string; name: string }

const fmt = (n: number) => new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(n);

export default function BudgetPage() {
  const { canAdmin, user } = useAuth();
  const [items, setItems] = useState<BudgetItem[]>([]);
  const [depts, setDepts] = useState<Dept[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<BudgetItem | null>(null);
  const [form, setForm] = useState({ title: "", description: "", amount: "", kind: "expense", department_id: "none", fiscal_year: new Date().getFullYear() });

  const load = async () => {
    setLoading(true);
    const [{ data: bi }, { data: ds }] = await Promise.all([
      supabase.from("budget_items").select("*").order("created_at", { ascending: false }),
      supabase.from("departments").select("id, name"),
    ]);
    setItems((bi as any) || []);
    setDepts((ds as any) || []);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const revenue = items.filter(i => i.kind === "revenue").reduce((s, i) => s + Number(i.amount), 0);
  const expense = items.filter(i => i.kind === "expense").reduce((s, i) => s + Number(i.amount), 0);
  const balance = revenue - expense;

  const byDept = depts.map(d => ({
    name: d.name,
    total: items.filter(i => i.department_id === d.id && i.kind === "expense").reduce((s, i) => s + Number(i.amount), 0),
  }));
  const unassigned = items.filter(i => !i.department_id && i.kind === "expense").reduce((s, i) => s + Number(i.amount), 0);
  if (unassigned > 0) byDept.push({ name: "غير مخصص", total: unassigned });
  const maxDept = Math.max(1, ...byDept.map(d => d.total));

  const reset = () => {
    setEditing(null);
    setForm({ title: "", description: "", amount: "", kind: "expense", department_id: "none", fiscal_year: new Date().getFullYear() });
  };

  const openCreate = () => { reset(); setOpen(true); };
  const openEdit = (it: BudgetItem) => {
    setEditing(it);
    setForm({
      title: it.title,
      description: it.description || "",
      amount: String(it.amount),
      kind: it.kind,
      department_id: it.department_id || "none",
      fiscal_year: it.fiscal_year,
    });
    setOpen(true);
  };

  const save = async () => {
    if (!form.title || !form.amount) { toast.error("العنوان والمبلغ مطلوبان"); return; }
    const payload = {
      title: form.title,
      description: form.description || null,
      amount: Number(form.amount),
      kind: form.kind,
      department_id: form.department_id === "none" ? null : form.department_id,
      fiscal_year: Number(form.fiscal_year),
    };
    if (editing) {
      const { error } = await supabase.from("budget_items").update(payload).eq("id", editing.id);
      if (error) return toast.error(error.message);
      toast.success("تم التحديث");
    } else {
      const { error } = await supabase.from("budget_items").insert({ ...payload, created_by: user?.id });
      if (error) return toast.error(error.message);
      toast.success("تمت الإضافة");
      const deptName = depts.find(d => d.id === payload.department_id)?.name || "غير مخصص";
      supabase.functions.invoke("discord-notify", {
        body: {
          type: "budget",
          data: {
            "العنوان": payload.title,
            "النوع": payload.kind === "revenue" ? "إيراد" : "مصروف",
            "المبلغ": new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(payload.amount),
            "القسم": deptName,
            "السنة المالية": payload.fiscal_year,
            "الوصف": payload.description || "-",
          },
        },
      }).catch(() => {});
    }
    setOpen(false);
    reset();
    load();
  };

  const remove = async (id: string) => {
    if (!confirm("حذف هذا البند؟")) return;
    const { error } = await supabase.from("budget_items").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("تم الحذف");
    load();
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto" dir="rtl">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Landmark className="h-7 w-7 text-primary" />
          <div>
            <h1 className="font-heading text-2xl font-bold gold-text">ميزانية الدولة</h1>
            <p className="text-xs text-muted-foreground">السنة المالية {new Date().getFullYear()}</p>
          </div>
        </div>
        {canAdmin && (
          <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) reset(); }}>
            <DialogTrigger asChild>
              <Button onClick={openCreate} className="gap-2"><Plus className="h-4 w-4" /> إضافة بند</Button>
            </DialogTrigger>
            <DialogContent dir="rtl">
              <DialogHeader><DialogTitle>{editing ? "تعديل بند" : "بند جديد"}</DialogTitle></DialogHeader>
              <div className="space-y-3">
                <div><Label>العنوان</Label><Input value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} /></div>
                <div><Label>الوصف</Label><Textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} /></div>
                <div className="grid grid-cols-2 gap-3">
                  <div><Label>المبلغ (ر.س)</Label><Input type="number" value={form.amount} onChange={e => setForm({ ...form, amount: e.target.value })} /></div>
                  <div><Label>السنة المالية</Label><Input type="number" value={form.fiscal_year} onChange={e => setForm({ ...form, fiscal_year: Number(e.target.value) })} /></div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label>النوع</Label>
                    <Select value={form.kind} onValueChange={v => setForm({ ...form, kind: v })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="expense">مصروف</SelectItem>
                        <SelectItem value="revenue">إيراد</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>القسم</Label>
                    <Select value={form.department_id} onValueChange={v => setForm({ ...form, department_id: v })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">غير مخصص</SelectItem>
                        {depts.map(d => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <Button onClick={save} className="w-full">{editing ? "حفظ التعديلات" : "إضافة"}</Button>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="border-emerald-500/30 bg-emerald-500/5">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-heading text-emerald-400">إجمالي الإيرادات</CardTitle>
            <TrendingUp className="h-4 w-4 text-emerald-400" />
          </CardHeader>
          <CardContent><div className="text-2xl font-bold text-emerald-300">{fmt(revenue)}</div></CardContent>
        </Card>
        <Card className="border-red-500/30 bg-red-500/5">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-heading text-red-400">إجمالي المصروفات</CardTitle>
            <TrendingDown className="h-4 w-4 text-red-400" />
          </CardHeader>
          <CardContent><div className="text-2xl font-bold text-red-300">{fmt(expense)}</div></CardContent>
        </Card>
        <Card className="gold-border bg-primary/5">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-heading text-primary">الرصيد الصافي</CardTitle>
            <Wallet className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent><div className={`text-2xl font-bold ${balance >= 0 ? "text-primary" : "text-red-400"}`}>{fmt(balance)}</div></CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader><CardTitle className="font-heading text-base">توزيع المصروفات على الأقسام</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          {byDept.length === 0 && <p className="text-sm text-muted-foreground">لا توجد بيانات</p>}
          {byDept.map((d, i) => (
            <div key={i}>
              <div className="flex justify-between text-sm mb-1">
                <span className="font-heading">{d.name}</span>
                <span className="text-muted-foreground">{fmt(d.total)}</span>
              </div>
              <div className="h-2 bg-muted rounded-full overflow-hidden">
                <div className="h-full bg-gradient-to-l from-primary to-primary/50" style={{ width: `${(d.total / maxDept) * 100}%` }} />
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="font-heading text-base">بنود الميزانية</CardTitle></CardHeader>
        <CardContent>
          {loading ? <p className="text-sm text-muted-foreground">جاري التحميل...</p> : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-right">العنوان</TableHead>
                  <TableHead className="text-right">النوع</TableHead>
                  <TableHead className="text-right">القسم</TableHead>
                  <TableHead className="text-right">المبلغ</TableHead>
                  <TableHead className="text-right">السنة</TableHead>
                  {canAdmin && <TableHead className="text-right">إجراءات</TableHead>}
                </TableRow>
              </TableHeader>
              <TableBody>
                {items.length === 0 && (
                  <TableRow><TableCell colSpan={canAdmin ? 6 : 5} className="text-center text-muted-foreground">لا توجد بنود</TableCell></TableRow>
                )}
                {items.map(it => (
                  <TableRow key={it.id}>
                    <TableCell className="font-medium">{it.title}</TableCell>
                    <TableCell>
                      <span className={`px-2 py-0.5 rounded text-xs ${it.kind === "revenue" ? "bg-emerald-500/15 text-emerald-400" : "bg-red-500/15 text-red-400"}`}>
                        {it.kind === "revenue" ? "إيراد" : "مصروف"}
                      </span>
                    </TableCell>
                    <TableCell className="text-muted-foreground text-sm">{depts.find(d => d.id === it.department_id)?.name || "—"}</TableCell>
                    <TableCell className="font-mono">{fmt(Number(it.amount))}</TableCell>
                    <TableCell>{it.fiscal_year}</TableCell>
                    {canAdmin && (
                      <TableCell>
                        <div className="flex gap-1">
                          <Button size="icon" variant="ghost" onClick={() => openEdit(it)}><Pencil className="h-3.5 w-3.5" /></Button>
                          <Button size="icon" variant="ghost" onClick={() => remove(it.id)}><Trash2 className="h-3.5 w-3.5 text-red-400" /></Button>
                        </div>
                      </TableCell>
                    )}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
