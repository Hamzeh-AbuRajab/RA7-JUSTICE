import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { User } from "@supabase/supabase-js";

type AppRole = "law" | "judge" | "attorney_general" | "deputy_attorney_general";

interface AuthCtx {
  user: User | null;
  role: AppRole | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string, fullName: string) => Promise<void>;
  signOut: () => Promise<void>;
  canManage: boolean;
  canAdmin: boolean;
  roleName: string;
  userDepartments: string[]; // department IDs
}

const roleLabels: Record<AppRole, string> = {
  law: "Law",
  judge: "Judge",
  deputy_attorney_general: "Deputy Attorney General",
  attorney_general: "Attorney General",
};

const AuthContext = createContext<AuthCtx | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [role, setRole] = useState<AppRole | null>(null);
  const [loading, setLoading] = useState(true);
  const [userDepartments, setUserDepartments] = useState<string[]>([]);

  const fetchRole = async (uid: string) => {
    const { data } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", uid)
      .maybeSingle();
    setRole((data?.role as AppRole) ?? null);
  };

  const fetchUserDepartments = async (uid: string) => {
    const { data } = await supabase
      .from("user_departments")
      .select("department_id")
      .eq("user_id", uid);
    setUserDepartments((data || []).map((d: any) => d.department_id));
  };

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      const u = session?.user ?? null;
      setUser(u);
      if (u) {
        Promise.all([fetchRole(u.id), fetchUserDepartments(u.id)]).finally(() => setLoading(false));
      } else {
        setRole(null);
        setUserDepartments([]);
        setLoading(false);
      }
    });

    supabase.auth.getSession().then(async ({ data: { session } }) => {
      const u = session?.user ?? null;
      setUser(u);
      if (u) {
        await Promise.all([fetchRole(u.id), fetchUserDepartments(u.id)]);
      }
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw error;
  };

  const signUp = async (email: string, password: string, fullName: string) => {
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: { full_name: fullName }, emailRedirectTo: window.location.origin },
    });
    if (error) throw error;
  };

  const signOut = async () => {
    setUser(null);
    setRole(null);
    setUserDepartments([]);
    await supabase.auth.signOut();
  };

  const canManage = role === "attorney_general" || role === "deputy_attorney_general" || role === "judge";
  const canAdmin = role === "attorney_general" || role === "deputy_attorney_general";
  const roleName = role ? roleLabels[role] : "";

  return (
    <AuthContext.Provider value={{ user, role, loading, signIn, signUp, signOut, canManage, canAdmin, roleName, userDepartments }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
