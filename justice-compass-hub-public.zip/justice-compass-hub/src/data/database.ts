// قاعدة البيانات الثابتة

export interface Announcement {
  id: number;
  title: string;
  type: "إعلان" | "استدعاء" | "تعميم" | "قرار";
  date: string;
  content: string;
}

export interface Department {
  id: number;
  name: string;
  description: string;
  icon: string;
  head: string;
  phone: string;
}

export interface Application {
  id: number;
  fullName: string;
  nationalId: string;
  phone: string;
  department: string;
  type: string;
  message: string;
  date: string;
  status: "جديد" | "قيد المراجعة" | "مقبول" | "مرفوض";
}

export interface Archive {
  id: number;
  title: string;
  type: "وثيقة" | "قرار" | "مرسوم" | "تعميم" | "تقرير" | "مذكرة" | "استدعاء" | "خطاب" | "محضر";
  date: string;
  reference: string;
  from?: string;
  to?: string;
  body?: string;
}

export interface Template {
  id: number;
  name: string;
  type: "تقرير" | "مذكرة" | "استدعاء" | "خطاب" | "محضر";
  description: string;
}

export interface Staff {
  id: number;
  name: string;
  position: string;
  department: string;
  phone: string;
  email: string;
  joinDate: string;
  photo?: string;
}

export interface SessionRequest {
  id: number;
  fullName: string;
  nationalId: string;
  phone: string;
  caseNumber: string;
  reason: string;
  preferredDate: string;
  date: string;
  status: "جديد" | "مقبول" | "مرفوض";
}

// البيانات
export const announcements: Announcement[] = [];

export let departments: Department[] = [
  { id: 1, name: "الغرف التجارية", description: "إدارة وتنظيم الشؤون التجارية والنزاعات التجارية وتسجيل الشركات", icon: "Building2", head: "المستشار فهد العمري", phone: "011-4567891" },
  { id: 2, name: "الشؤون القانونية", description: "تقديم الاستشارات القانونية وصياغة التشريعات ومراجعة العقود الحكومية", icon: "Scale", head: "المستشارة نورة السعيد", phone: "011-4567892" },
  { id: 3, name: "نقابة المحامين", description: "تنظيم مهنة المحاماة وإصدار التراخيص والرقابة على أداء المحامين", icon: "Gavel", head: "المستشار خالد المنصور", phone: "011-4567893" },
];

export function addDepartment(d: Omit<Department, "id">): Department {
  const newDept: Department = { ...d, id: departments.length + 1 };
  departments = [...departments, newDept];
  return newDept;
}

export function removeDepartment(id: number) {
  departments = departments.filter((d) => d.id !== id);
}

export let archives: Archive[] = [];

export function addArchive(data: { type: Archive["type"]; title: string; from?: string; to?: string; body?: string; date: string }): Archive {
  const prefix: Record<string, string> = {
    "تقرير": "TQ", "مذكرة": "MZ", "استدعاء": "ST", "خطاب": "KH", "محضر": "MH",
    "وثيقة": "WQ", "قرار": "QR", "مرسوم": "MR", "تعميم": "TM",
  };
  const newArchive: Archive = {
    id: archives.length + 1,
    title: data.title,
    type: data.type,
    date: data.date,
    reference: `${prefix[data.type] || "XX"}-${new Date().getFullYear()}-${String(archives.length + 1).padStart(3, "0")}`,
    from: data.from,
    to: data.to,
    body: data.body,
  };
  archives = [...archives, newArchive];
  return newArchive;
}

export const templates: Template[] = [
  { id: 1, name: "نموذج تقرير رسمي", type: "تقرير", description: "نموذج معتمد لكتابة التقارير الرسمية والإدارية" },
  { id: 2, name: "نموذج مذكرة داخلية", type: "مذكرة", description: "نموذج للمراسلات الداخلية بين الأقسام والإدارات" },
  { id: 3, name: "نموذج استدعاء محكمة", type: "استدعاء", description: "نموذج رسمي لاستدعاء الأطراف أمام المحكمة" },
  { id: 4, name: "نموذج خطاب رسمي", type: "خطاب", description: "نموذج للمراسلات الرسمية الصادرة من الوزارة" },
  { id: 5, name: "نموذج محضر اجتماع", type: "محضر", description: "نموذج لتوثيق محاضر الاجتماعات والجلسات" },
];

export let staff: Staff[] = [];

export function addStaff(s: Omit<Staff, "id">): Staff {
  const newStaff: Staff = { ...s, id: staff.length + 1 };
  staff = [...staff, newStaff];
  return newStaff;
}

export function removeStaff(id: number) {
  staff = staff.filter((s) => s.id !== id);
}

// Applications store
export let applications: Application[] = [];

export function addApplication(app: Omit<Application, "id" | "date" | "status">): Application {
  const newApp: Application = {
    ...app,
    id: applications.length + 1,
    date: new Date().toISOString().split("T")[0],
    status: "جديد",
  };
  applications = [...applications, newApp];
  return newApp;
}

// Session requests store
export let sessionRequests: SessionRequest[] = [];

export function addSessionRequest(req: Omit<SessionRequest, "id" | "date" | "status">): SessionRequest {
  const newReq: SessionRequest = {
    ...req,
    id: sessionRequests.length + 1,
    date: new Date().toISOString().split("T")[0],
    status: "جديد",
  };
  sessionRequests = [...sessionRequests, newReq];
  return newReq;
}
