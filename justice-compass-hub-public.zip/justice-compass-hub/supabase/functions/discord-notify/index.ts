import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';

const WEBHOOKS: Record<string, string | undefined> = {
  apply: Deno.env.get('DISCORD_WEBHOOK_APPLY'),
  archives: Deno.env.get('DISCORD_WEBHOOK_ARCHIVES'),
  session: Deno.env.get('DISCORD_WEBHOOK_SESSION'),
  budget: Deno.env.get('DISCORD_WEBHOOK_BUDGET'),
  memo: Deno.env.get('DISCORD_WEBHOOK_MEMO'),
  admin: Deno.env.get('DISCORD_WEBHOOK_ADMIN'),
};

const TITLES: Record<string, string> = {
  apply: 'التقديم',
  archives: 'الأرشيفات',
  session: 'طلب جلسة',
  budget: 'ميزانية الدولة',
  memo: 'طلب مذكرة',
  admin: 'سجل الإدارة',
};

const COLORS: Record<string, number> = {
  apply: 0xD4A017,
  archives: 0x4A90E2,
  session: 0x9B59B6,
  budget: 0x27AE60,
  memo: 0xE67E22,
  admin: 0xC0392B,
};

const LOGO_URL = 'https://justice-compass-hub.lovable.app/doj-logo.png';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  try {
    const { type, data } = await req.json();
    const webhook = WEBHOOKS[type];
    if (!webhook) {
      return new Response(JSON.stringify({ error: 'Invalid type or webhook missing' }), {
        status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // All fields inline:false => vertical/long layout (stacked, not side-by-side)
    const fields = Object.entries(data || {})
      .filter(([_, v]) => v !== null && v !== undefined && String(v).trim() !== '')
      .map(([name, value]) => ({
        name: String(name),
        value: String(value).slice(0, 1024),
        inline: false,
      }))
      .slice(0, 25);

    const now = new Date();
    const dateStr = now.toLocaleString('en-US', {
      year: 'numeric', month: 'long', day: 'numeric',
      hour: '2-digit', minute: '2-digit', hour12: true,
    });

    const embed = {
      title: `📋 ${TITLES[type]}`,
      color: COLORS[type] ?? 0xD4A017,
      fields,
      thumbnail: { url: LOGO_URL },
      author: { name: 'Department of Justice', icon_url: LOGO_URL },
      footer: { text: `Department of Justice • ${dateStr}`, icon_url: LOGO_URL },
      timestamp: now.toISOString(),
    };

    const res = await fetch(webhook, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: 'Department of Justice', avatar_url: LOGO_URL, embeds: [embed] }),
    });

    if (!res.ok) {
      const text = await res.text();
      return new Response(JSON.stringify({ error: 'Discord error', detail: text }), {
        status: 502, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    return new Response(JSON.stringify({ ok: true }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), {
      status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
