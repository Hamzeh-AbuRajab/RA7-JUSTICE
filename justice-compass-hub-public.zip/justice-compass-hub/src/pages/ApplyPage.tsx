import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { FileText, Send } from "lucide-react";

export default function ApplyPage() {
  const [departments, setDepartments] = useState<any[]>([]);
  const [form, setForm] = useState({
    fullName: "", nationalId: "", phone: "", department: "", type: "", message: "",
  });

  useEffect(() => {
    supabase.from("departments").select("id, name").then(({ data }) => setDepartments(data || []));
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.fullName || !form.nationalId || !form.phone || !form.department || !form.type) {
      toast.error("يرجى تعبئة جميع الحقول المطلوبة"); return;
    }
    const { error } = await supabase.from("applications").insert({
      full_name: form.fullName, national_id: form.nationalId, phone: form.phone,
      department: form.department, type: form.type, message: form.message,
      date: new Date().toISOString().split("T")[0],
    });
    if (error) { toast.error("حدث خطأ أثناء الإرسال"); return; }
    toast.success("تم إرسال طلبك بنجاح ✅");
    supabase.functions.invoke("discord-notify", {
      body: {
        type: "apply",
        data: {
          "الاسم الكامل": form.fullName,
          "اسم مستخدم Discord": form.nationalId,
          "رقم الجوال": form.phone,
          "القسم": form.department,
          "نوع الطلب": form.type,
          "الرسالة": form.message || "-",
        },
      },
    }).catch(() => {});
    setForm({ fullName: "", nationalId: "", phone: "", department: "", type: "", message: "" });
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="glass-card rounded-2xl overflow-hidden gold-border animate-fade-in">
        <div className="bg-primary/10 p-5 border-b border-border/30 flex items-center gap-3">
          <div className="bg-primary/20 p-2 rounded-lg"><FileText className="h-6 w-6 text-primary" /></div>
          <div>
            <h1 className="font-heading text-xl font-black">نموذج التقديم</h1>
            <p className="text-xs text-muted-foreground">قدّم طلبك على وزارة العدل</p>
          </div>
        </div>
        <div className="p-6">
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label className="font-heading text-xs font-bold">الاسم الكامل *</Label>
                <Input value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} placeholder="أدخل الاسم الكامل" className="bg-secondary/50 border-border/50" />
              </div>
              <div className="space-y-2">
                <Label className="font-heading text-xs font-bold">اسم مستخدم Discord *</Label>
                <Input value={form.nationalId} onChange={(e) => setForm({ ...form, nationalId: e.target.value })} placeholder="أدخل اسم مستخدم Discord" className="bg-secondary/50 border-border/50" />
              </div>
            </div>
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label className="font-heading text-xs font-bold">رقم الجوال *</Label>
                <Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="05XXXXXXXX" className="bg-secondary/50 border-border/50" />
              </div>
              <div className="space-y-2">
                <Label className="font-heading text-xs font-bold">القسم *</Label>
                <Select value={form.department} onValueChange={(v) => setForm({ ...form, department: v })}>
                  <SelectTrigger className="bg-secondary/50 border-border/50"><SelectValue placeholder="اختر القسم" /></SelectTrigger>
                  <SelectContent>
                    {departments.map((d) => <SelectItem key={d.id} value={d.name}>{d.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label className="font-heading text-xs font-bold">نوع الطلب *</Label>
              <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v })}>
                <SelectTrigger className="bg-secondary/50 border-border/50"><SelectValue placeholder="اختر النوع" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="توظيف">توظيف</SelectItem>
                  <SelectItem value="تدريب">تدريب</SelectItem>
                  <SelectItem value="استشارة">استشارة</SelectItem>
                  <SelectItem value="شكوى">شكوى</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label className="font-heading text-xs font-bold">الرسالة</Label>
              <Textarea value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} placeholder="اكتب رسالتك هنا..." rows={4} className="bg-secondary/50 border-border/50" />
            </div>
            <Button type="submit" className="w-full gold-gradient text-primary-foreground font-heading font-bold hover:opacity-90 gold-glow h-11">
              <Send className="h-4 w-4 ml-2" />إرسال الطلب
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}
