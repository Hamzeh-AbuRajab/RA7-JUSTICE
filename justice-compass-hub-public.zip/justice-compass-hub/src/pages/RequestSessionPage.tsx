import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Gavel, Send } from "lucide-react";

export default function RequestSessionPage() {
  const [form, setForm] = useState({
    fullName: "", nationalId: "", phone: "", caseNumber: "", reason: "", preferredDate: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.fullName || !form.nationalId || !form.phone || !form.caseNumber || !form.reason || !form.preferredDate) {
      toast.error("يرجى تعبئة جميع الحقول المطلوبة"); return;
    }
    const { error } = await supabase.from("session_requests").insert({
      full_name: form.fullName, national_id: form.nationalId, phone: form.phone,
      case_number: form.caseNumber, reason: form.reason, preferred_date: form.preferredDate,
      date: new Date().toISOString().split("T")[0],
    });
    if (error) { toast.error("حدث خطأ أثناء الإرسال"); return; }
    toast.success("تم إرسال طلب الجلسة بنجاح ✅");
    supabase.functions.invoke("discord-notify", {
      body: {
        type: "session",
        data: {
          "الاسم الكامل": form.fullName,
          "اسم مستخدم Discord": form.nationalId,
          "رقم الجوال": form.phone,
          "رقم القضية": form.caseNumber,
          "التاريخ المفضل": form.preferredDate,
          "سبب الطلب": form.reason,
        },
      },
    }).catch(() => {});
    setForm({ fullName: "", nationalId: "", phone: "", caseNumber: "", reason: "", preferredDate: "" });
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="glass-card rounded-2xl overflow-hidden gold-border animate-fade-in">
        <div className="bg-primary/10 p-5 border-b border-border/30 flex items-center gap-3">
          <div className="bg-primary/20 p-2 rounded-lg"><Gavel className="h-6 w-6 text-primary" /></div>
          <div>
            <h1 className="font-heading text-xl font-black">طلب جلسة مع القاضي</h1>
            <p className="text-xs text-muted-foreground">قدّم طلب موعد جلسة رسمية</p>
          </div>
        </div>
        <div className="p-6">
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label className="font-heading text-xs font-bold">الاسم الكامل *</Label>
                <Input value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} placeholder="أدخل الاسم الكامل" className="bg-secondary/50 border-border/50" />
              </div>
              <div className="space-y-2">
                <Label className="font-heading text-xs font-bold">اسم مستخدم Discord *</Label>
                <Input value={form.nationalId} onChange={(e) => setForm({ ...form, nationalId: e.target.value })} placeholder="أدخل اسم مستخدم Discord" className="bg-secondary/50 border-border/50" />
              </div>
            </div>
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label className="font-heading text-xs font-bold">رقم الجوال *</Label>
                <Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="05XXXXXXXX" className="bg-secondary/50 border-border/50" />
              </div>
              <div className="space-y-2">
                <Label className="font-heading text-xs font-bold">رقم القضية *</Label>
                <Input value={form.caseNumber} onChange={(e) => setForm({ ...form, caseNumber: e.target.value })} placeholder="أدخل رقم القضية" className="bg-secondary/50 border-border/50" />
              </div>
            </div>
            <div className="space-y-2">
              <Label className="font-heading text-xs font-bold">التاريخ المفضل للجلسة *</Label>
              <Input type="date" value={form.preferredDate} onChange={(e) => setForm({ ...form, preferredDate: e.target.value })} className="bg-secondary/50 border-border/50" />
            </div>
            <div className="space-y-2">
              <Label className="font-heading text-xs font-bold">سبب الطلب *</Label>
              <Textarea value={form.reason} onChange={(e) => setForm({ ...form, reason: e.target.value })} placeholder="اكتب سبب طلب الجلسة..." rows={4} className="bg-secondary/50 border-border/50" />
            </div>
            <Button type="submit" className="w-full gold-gradient text-primary-foreground font-heading font-bold hover:opacity-90 gold-glow h-11">
              <Send className="h-4 w-4 ml-2" />إرسال طلب الجلسة
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}
