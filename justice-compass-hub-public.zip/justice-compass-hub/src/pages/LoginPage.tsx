import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import dojLogo from "@/assets/doj-logo.png";
import { LogIn, UserPlus } from "lucide-react";

export default function LoginPage() {
  const { signIn, signUp, user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [isSignUp, setIsSignUp] = useState(false);
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({ email: "", password: "", fullName: "" });

  // Redirect if already logged in
  useEffect(() => {
    if (!authLoading && user) {
      navigate("/", { replace: true });
    }
  }, [user, authLoading, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (isSignUp) {
        if (!form.fullName) { toast.error("يرجى إدخال الاسم"); setLoading(false); return; }
        await signUp(form.email, form.password, form.fullName);
        toast.success("تم إنشاء الحساب بنجاح ✅");
      } else {
        await signIn(form.email, form.password);
        toast.success("تم تسجيل الدخول ✅");
      }
      navigate("/", { replace: true });
    } catch (err: any) {
      toast.error(err.message || "حدث خطأ");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen grid-bg flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <img src={dojLogo} alt="DOJ" width={80} height={80} className="mx-auto mb-4 drop-shadow-[0_0_20px_hsl(42,78%,50%,0.3)]" />
          <h1 className="font-heading text-2xl font-black text-foreground">وزارة <span className="text-primary gold-text">العدل</span></h1>
          <p className="text-primary/80 text-sm font-heading tracking-widest mt-1">Department of Justice</p>
        </div>

        <div className="glass-card rounded-2xl gold-border p-6">
          <h2 className="font-heading font-bold text-lg mb-6 text-center">
            {isSignUp ? "إنشاء حساب جديد" : "تسجيل الدخول"}
          </h2>

          <form onSubmit={handleSubmit} className="space-y-4">
            {isSignUp && (
              <div className="space-y-2">
                <Label className="font-heading text-xs font-bold">الاسم الكامل</Label>
                <Input value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} placeholder="أدخل اسمك" className="bg-secondary/50 border-border/50" />
              </div>
            )}
            <div className="space-y-2">
              <Label className="font-heading text-xs font-bold">البريد الإلكتروني</Label>
              <Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="email@example.com" className="bg-secondary/50 border-border/50" dir="ltr" />
            </div>
            <div className="space-y-2">
              <Label className="font-heading text-xs font-bold">كلمة المرور</Label>
              <Input type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} placeholder="••••••••" className="bg-secondary/50 border-border/50" dir="ltr" />
            </div>
            <Button type="submit" disabled={loading} className="w-full gold-gradient text-primary-foreground font-heading font-bold hover:opacity-90 gold-glow h-11">
              {isSignUp ? <UserPlus className="h-4 w-4 ml-2" /> : <LogIn className="h-4 w-4 ml-2" />}
              {loading ? "جاري..." : isSignUp ? "إنشاء حساب" : "تسجيل الدخول"}
            </Button>
          </form>

          <div className="mt-4 text-center">
            <button onClick={() => setIsSignUp(!isSignUp)} className="text-xs text-primary hover:underline font-heading">
              {isSignUp ? "لديك حساب؟ سجل دخول" : "ليس لديك حساب؟ أنشئ حساب"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
