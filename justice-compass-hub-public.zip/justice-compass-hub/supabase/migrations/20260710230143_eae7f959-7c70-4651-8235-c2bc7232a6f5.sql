
-- 1) Tighten archives SELECT: judges+
DROP POLICY IF EXISTS "Authenticated can view archives" ON public.archives;
CREATE POLICY "Judges+ can view archives"
  ON public.archives FOR SELECT TO authenticated
  USING (
    has_role(auth.uid(), 'attorney_general'::app_role)
    OR has_role(auth.uid(), 'deputy_attorney_general'::app_role)
    OR has_role(auth.uid(), 'judge'::app_role)
  );

-- 2) Tighten staff SELECT: judges+ OR own record (own email)
DROP POLICY IF EXISTS "Authenticated can view staff" ON public.staff;
CREATE POLICY "Judges+ or self can view staff"
  ON public.staff FOR SELECT TO authenticated
  USING (
    has_role(auth.uid(), 'attorney_general'::app_role)
    OR has_role(auth.uid(), 'deputy_attorney_general'::app_role)
    OR has_role(auth.uid(), 'judge'::app_role)
    OR lower(email) = lower((SELECT au.email FROM auth.users au WHERE au.id = auth.uid()))
  );

-- 3) Reduce SECURITY DEFINER exposure
-- Revoke execute on admin-only auth lookups from anon/authenticated; keep service_role.
REVOKE ALL ON FUNCTION public.find_user_by_email(text) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.get_user_email(uuid)     FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.find_user_by_email(text) TO service_role;
GRANT EXECUTE ON FUNCTION public.get_user_email(uuid)     TO service_role;

-- Trigger-only function — no client role needs execute.
REVOKE ALL ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;

-- Helper only ever called with auth.uid(); can safely run as INVOKER (own-row policies allow read).
ALTER FUNCTION public.get_user_role(uuid)                     SECURITY INVOKER;
ALTER FUNCTION public.user_has_department_access(uuid, uuid)  SECURITY INVOKER;

-- has_role is still SECURITY DEFINER on purpose (RLS uses it and needs stable behavior across schemas).
