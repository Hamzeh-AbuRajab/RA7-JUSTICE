
CREATE TABLE public.commercial_license_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name text NOT NULL,
  national_id text NOT NULL,
  phone text NOT NULL,
  business_name text NOT NULL,
  business_type text NOT NULL,
  address text NOT NULL,
  capital text,
  notes text,
  status text NOT NULL DEFAULT 'جديد',
  date date NOT NULL DEFAULT (now()::date),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.commercial_license_requests TO authenticated;
GRANT INSERT ON public.commercial_license_requests TO anon;
GRANT ALL ON public.commercial_license_requests TO service_role;

ALTER TABLE public.commercial_license_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can submit commercial license request"
  ON public.commercial_license_requests FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Managers can view commercial license requests"
  ON public.commercial_license_requests FOR SELECT
  TO authenticated
  USING (
    private.has_role(auth.uid(), 'judge'::app_role)
    OR private.has_role(auth.uid(), 'attorney_general'::app_role)
    OR private.has_role(auth.uid(), 'deputy_attorney_general'::app_role)
  );

CREATE POLICY "Managers can update commercial license requests"
  ON public.commercial_license_requests FOR UPDATE
  TO authenticated
  USING (
    private.has_role(auth.uid(), 'judge'::app_role)
    OR private.has_role(auth.uid(), 'attorney_general'::app_role)
    OR private.has_role(auth.uid(), 'deputy_attorney_general'::app_role)
  );

CREATE POLICY "Managers can delete commercial license requests"
  ON public.commercial_license_requests FOR DELETE
  TO authenticated
  USING (
    private.has_role(auth.uid(), 'judge'::app_role)
    OR private.has_role(auth.uid(), 'attorney_general'::app_role)
    OR private.has_role(auth.uid(), 'deputy_attorney_general'::app_role)
  );

CREATE TRIGGER set_commercial_license_requests_updated_at
  BEFORE UPDATE ON public.commercial_license_requests
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
