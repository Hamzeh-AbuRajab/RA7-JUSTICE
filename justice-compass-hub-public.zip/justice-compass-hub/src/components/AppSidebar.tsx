import {
  Home, Megaphone, LayoutGrid, FileText, Archive, FileSignature, Users, Settings, Gavel, Landmark, Store, ScrollText,
} from "lucide-react";
import { NavLink } from "@/components/NavLink";
import { useLocation } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import dojLogo from "@/assets/doj-logo.png";

import {
  Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent, SidebarGroupLabel,
  SidebarMenu, SidebarMenuButton, SidebarMenuItem, useSidebar,
} from "@/components/ui/sidebar";

const publicItems = [
  { title: "الرئيسية", url: "/", icon: Home },
  { title: "الإعلانات والاستدعاءات", url: "/announcements", icon: Megaphone },
  { title: "الأقسام", url: "/departments", icon: LayoutGrid },
  { title: "التقديم", url: "/apply", icon: FileText },
  { title: "طلب جلسة", url: "/request-session", icon: Gavel },
  { title: "رخصة تجارية", url: "/license", icon: Store },
  { title: "طلب مذكرة", url: "/memo", icon: ScrollText },
  { title: "منسوبي العدل", url: "/staff", icon: Users },
];

const protectedItems = [
  { title: "الأرشيفات", url: "/archives", icon: Archive },
  { title: "النماذج", url: "/templates", icon: FileSignature },
];

export function AppSidebar() {
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  const location = useLocation();
  const { canManage, canAdmin } = useAuth();

  return (
    <Sidebar collapsible="icon" side="right">
      <SidebarContent className="grid-bg">
        <div className="p-4 border-b border-sidebar-border">
          <div className="flex items-center gap-3">
            <img src={dojLogo} alt="Department of Justice" width={44} height={44} className="rounded-full" />
            {!collapsed && (
              <div>
                <h2 className="font-heading text-sm font-bold text-primary gold-text">وزارة العدل</h2>
                <p className="text-[10px] text-sidebar-foreground/50 font-heading tracking-wide">Department of Justice</p>
              </div>
            )}
          </div>
        </div>

        <SidebarGroup>
          <SidebarGroupLabel className="text-sidebar-foreground/40 font-heading text-[10px] tracking-widest uppercase">القائمة الرئيسية</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {publicItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild>
                    <NavLink to={item.url} end={item.url === "/"} className="hover:bg-sidebar-accent/60 transition-all duration-200 rounded-lg" activeClassName="bg-sidebar-accent gold-border text-sidebar-primary font-medium">
                      <item.icon className="ml-2 h-4 w-4" />
                      {!collapsed && <span className="text-sm">{item.title}</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {canManage && (
          <SidebarGroup>
            <SidebarGroupLabel className="text-sidebar-foreground/40 font-heading text-[10px] tracking-widest uppercase">مستندات</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {protectedItems.map((item) => (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton asChild>
                      <NavLink to={item.url} className="hover:bg-sidebar-accent/60 transition-all duration-200 rounded-lg" activeClassName="bg-sidebar-accent gold-border text-sidebar-primary font-medium">
                        <item.icon className="ml-2 h-4 w-4" />
                        {!collapsed && <span className="text-sm">{item.title}</span>}
                      </NavLink>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}

        {canManage && (
          <SidebarGroup>
            <SidebarGroupLabel className="text-sidebar-foreground/40 font-heading text-[10px] tracking-widest uppercase">الإدارة</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild>
                    <NavLink to="/admin" className="hover:bg-sidebar-accent/60 transition-all duration-200 rounded-lg" activeClassName="bg-sidebar-accent gold-border text-sidebar-primary font-medium">
                      <Settings className="ml-2 h-4 w-4" />
                      {!collapsed && <span className="text-sm">لوحة الإدارة</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                {canAdmin && (
                  <SidebarMenuItem>
                    <SidebarMenuButton asChild>
                      <NavLink to="/budget" className="hover:bg-sidebar-accent/60 transition-all duration-200 rounded-lg" activeClassName="bg-sidebar-accent gold-border text-sidebar-primary font-medium">
                        <Landmark className="ml-2 h-4 w-4" />
                        {!collapsed && <span className="text-sm">ميزانية الدولة</span>}
                      </NavLink>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                )}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}
      </SidebarContent>
    </Sidebar>
  );
}
