import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';
import { createClient } from 'npm:@supabase/supabase-js@2';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  const jsonHeaders = { ...corsHeaders, 'Content-Type': 'application/json' };

  try {
    const authHeader = req.headers.get('Authorization') ?? '';
    if (!authHeader.startsWith('Bearer ')) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: jsonHeaders });
    }

    const admin = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
    );

    // Identify caller from JWT
    const jwt = authHeader.replace('Bearer ', '');
    const { data: userData, error: userErr } = await admin.auth.getUser(jwt);
    if (userErr || !userData?.user) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: jsonHeaders });
    }
    const callerId = userData.user.id;

    // Only Attorney General / Deputy AG may call this
    const { data: roles } = await admin
      .from('user_roles')
      .select('role')
      .eq('user_id', callerId);
    const allowed = (roles ?? []).some((r: any) =>
      r.role === 'attorney_general' || r.role === 'deputy_attorney_general'
    );
    if (!allowed) {
      return new Response(JSON.stringify({ error: 'Forbidden' }), { status: 403, headers: jsonHeaders });
    }

    const body = await req.json().catch(() => ({}));
    const op = body?.op as string | undefined;

    if (op === 'email_by_id') {
      const uid = body?.user_id as string | undefined;
      if (!uid) return new Response(JSON.stringify({ error: 'user_id required' }), { status: 400, headers: jsonHeaders });
      const { data, error } = await admin.auth.admin.getUserById(uid);
      if (error) throw error;
      return new Response(JSON.stringify({ email: data?.user?.email ?? null }), { headers: jsonHeaders });
    }

    if (op === 'id_by_email') {
      const email = (body?.email as string | undefined)?.toLowerCase();
      if (!email) return new Response(JSON.stringify({ error: 'email required' }), { status: 400, headers: jsonHeaders });
      // Search via listUsers (paginated). For small user bases this is fine.
      let page = 1;
      const perPage = 200;
      while (page < 25) {
        const { data, error } = await admin.auth.admin.listUsers({ page, perPage });
        if (error) throw error;
        const match = data.users.find((u) => (u.email ?? '').toLowerCase() === email);
        if (match) return new Response(JSON.stringify({ user_id: match.id }), { headers: jsonHeaders });
        if (data.users.length < perPage) break;
        page++;
      }
      return new Response(JSON.stringify({ user_id: null }), { headers: jsonHeaders });
    }

    return new Response(JSON.stringify({ error: 'Unknown op' }), { status: 400, headers: jsonHeaders });
  } catch (e: any) {
    return new Response(JSON.stringify({ error: e?.message || String(e) }), {
      status: 500, headers: jsonHeaders,
    });
  }
});
