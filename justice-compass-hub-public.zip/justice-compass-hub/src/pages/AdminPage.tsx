import { useState, useEffect } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Users, Megaphone, FileText, Archive, LayoutGrid, Settings, TrendingUp, Plus, UserPlus, Trash2, Gavel, ImagePlus, Shield, Pencil, X, Check, Link2, Store, ScrollText } from "lucide-react";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";

type AppRole = "law" | "judge" | "attorney_general" | "deputy_attorney_general";

const roleLabels: Record<AppRole, string> = {
  law: "Law",
  judge: "Judge",
  deputy_attorney_general: "Deputy Attorney General",
  attorney_general: "Attorney General",
};

const POSITIONS = [
  "Minister of Justice",
  "Deputy Minister",
  "Judge",
  "Assistant Judge",
  "Prosecutor",
  "Lawyer",
  "Lawyer Trainee",
];

const logAdmin = (action: string, details: Record<string, any> = {}) => {
  supabase.functions.invoke("discord-notify", {
    body: { type: "admin", data: { "الإجراء": action, ...details } },
  }).catch(() => {});
};

export default function AdminPage() {
  const { user, role, canManage, canAdmin, loading } = useAuth();
  const navigate = useNavigate();

  const [applications, setApplications] = useState<any[]>([]);
  const [sessionRequests, setSessionRequests] = useState<any[]>([]);
  const [licenseRequests, setLicenseRequests] = useState<any[]>([]);
  const [memoRequests, setMemoRequests] = useState<any[]>([]);
  const [staffList, setStaff] = useState<any[]>([]);
  const [departments, setDepartments] = useState<any[]>([]);
  const [announcements, setAnnouncements] = useState<any[]>([]);
  const [archivesList, setArchives] = useState<any[]>([]);
  const [userRoles, setUserRoles] = useState<any[]>([]);
  const [userDeptLinks, setUserDeptLinks] = useState<any[]>([]);

  // Edit states
  const [editingAnn, setEditingAnn] = useState<any | null>(null);
  const [editingArc, setEditingArc] = useState<any | null>(null);
  const [editingStaff, setEditingStaff] = useState<any | null>(null);

  // Forms
  const [showAddStaff, setShowAddStaff] = useState(false);
  const [newStaff, setNewStaff] = useState({ name: "", position: "", department: "", department_id: "", phone: "", email: "", join_date: new Date().toISOString().split("T")[0], photo_url: "" });
  const [showAddDept, setShowAddDept] = useState(false);
  const [newDept, setNewDept] = useState({ name: "", description: "", icon: "Building2", head: "", phone: "" });
  const [showAddAnnouncement, setShowAddAnnouncement] = useState(false);
  const [newAnnouncement, setNewAnnouncement] = useState({ title: "", type: "إعلان", content: "", date: new Date().toISOString().split("T")[0], department_id: "" });
  const [showAddArchive, setShowAddArchive] = useState(false);
  const [newArchive, setNewArchive] = useState({ title: "", type: "وثيقة", reference: "", date: new Date().toISOString().split("T")[0], from_entity: "", to_entity: "", body: "", department_id: "" });

  // User-department linking
  const [linkEmail, setLinkEmail] = useState("");
  const [linkDepts, setLinkDepts] = useState<string[]>([]);

  const fetchAll = async () => {
    const [apps, sessions, licenses, memos, st, deps, anns, arcs] = await Promise.all([
      supabase.from("applications").select("*").order("created_at", { ascending: false }),
      supabase.from("session_requests").select("*").order("created_at", { ascending: false }),
      supabase.from("commercial_license_requests").select("*").order("created_at", { ascending: false }),
      supabase.from("memo_requests").select("*").order("created_at", { ascending: false }),
      supabase.from("staff").select("*").order("created_at", { ascending: true }),
      supabase.from("departments").select("*").order("created_at", { ascending: true }),
      supabase.from("announcements").select("*").order("created_at", { ascending: false }),
      supabase.from("archives").select("*").order("created_at", { ascending: false }),
    ]);
    setApplications(apps.data || []);
    setSessionRequests(sessions.data || []);
    setLicenseRequests(licenses.data || []);
    setMemoRequests(memos.data || []);
    setStaff(st.data || []);
    setDepartments(deps.data || []);
    setAnnouncements(anns.data || []);
    setArchives(arcs.data || []);
  };

  const lookupEmail = async (user_id: string): Promise<string> => {
    const { data } = await supabase.functions.invoke("admin-user-lookup", {
      body: { op: "email_by_id", user_id },
    });
    return (data as any)?.email || "";
  };

  const lookupUserId = async (email: string): Promise<string | null> => {
    const { data } = await supabase.functions.invoke("admin-user-lookup", {
      body: { op: "id_by_email", email },
    });
    return (data as any)?.user_id || null;
  };

  const fetchRoles = async () => {
    if (role !== "attorney_general") return;
    const { data } = await supabase.from("user_roles").select("*");
    const enriched = await Promise.all((data || []).map(async (ur) => ({
      ...ur, _email: await lookupEmail(ur.user_id),
    })));
    setUserRoles(enriched);
  };

  const fetchUserDeptLinks = async () => {
    if (role !== "attorney_general") return;
    const { data } = await supabase.from("user_departments").select("*");
    const enriched = await Promise.all((data || []).map(async (ud) => ({
      ...ud, _email: await lookupEmail(ud.user_id),
    })));
    setUserDeptLinks(enriched);
  };

  useEffect(() => {
    if (loading) return;
    if (!canManage) { navigate("/"); return; }
    fetchAll();
    fetchRoles();
    fetchUserDeptLinks();
  }, [canManage, loading]);

  const deptName = (id: string) => departments.find((d) => d.id === id)?.name || "";

  const statusColors: Record<string, string> = {
    "جديد": "bg-blue-500/15 text-blue-400",
    "قيد المراجعة": "bg-yellow-500/15 text-yellow-400",
    "مقبول": "bg-green-500/15 text-green-400",
    "مرفوض": "bg-red-500/15 text-red-400",
  };

  const handleAddStaff = async () => {
    if (!newStaff.name || !newStaff.position || !newStaff.department || !newStaff.phone || !newStaff.email) {
      toast.error("يرجى تعبئة جميع الحقول"); return;
    }
    const { department_id, ...rest } = newStaff;
    const { error } = await supabase.from("staff").insert({ ...rest, department_id: department_id || null });
    if (error) { toast.error("حدث خطأ"); return; }
    toast.success("تمت إضافة المنسوب بنجاح ✅");
    logAdmin("إضافة منسوب", { "الاسم": newStaff.name, "المنصب": newStaff.position, "القسم": newStaff.department, "البريد": newStaff.email, "بواسطة": user?.email || "-" });
    setNewStaff({ name: "", position: "", department: "", department_id: "", phone: "", email: "", join_date: new Date().toISOString().split("T")[0], photo_url: "" });
    setShowAddStaff(false);
    fetchAll();
  };

  const handleAddDept = async () => {
    if (!newDept.name || !newDept.description || !newDept.head || !newDept.phone) {
      toast.error("يرجى تعبئة جميع الحقول"); return;
    }
    const { error } = await supabase.from("departments").insert(newDept);
    if (error) { toast.error("حدث خطأ"); return; }
    toast.success("تمت إضافة القسم بنجاح ✅");
    logAdmin("إضافة قسم", { "الاسم": newDept.name, "رئيس القسم": newDept.head, "بواسطة": user?.email || "-" });
    setNewDept({ name: "", description: "", icon: "Building2", head: "", phone: "" });
    setShowAddDept(false);
    fetchAll();
  };

  const handleAddAnnouncement = async () => {
    if (!newAnnouncement.title || !newAnnouncement.content) {
      toast.error("يرجى تعبئة جميع الحقول"); return;
    }
    const { department_id, ...rest } = newAnnouncement;
    const { error } = await supabase.from("announcements").insert({ ...rest, created_by: user?.id, department_id: department_id || null });
    if (error) { toast.error("حدث خطأ"); return; }
    toast.success("تمت إضافة الإعلان بنجاح ✅");
    logAdmin("إضافة إعلان", { "العنوان": newAnnouncement.title, "النوع": newAnnouncement.type, "بواسطة": user?.email || "-" });
    setNewAnnouncement({ title: "", type: "إعلان", content: "", date: new Date().toISOString().split("T")[0], department_id: "" });
    setShowAddAnnouncement(false);
    fetchAll();
  };

  const handleAddArchive = async () => {
    if (!newArchive.title || !newArchive.reference) {
      toast.error("يرجى تعبئة العنوان والمرجع"); return;
    }
    const { department_id, ...rest } = newArchive;
    const { error } = await supabase.from("archives").insert({ ...rest, created_by: user?.id, department_id: department_id || null });
    if (error) { toast.error("حدث خطأ"); return; }
    toast.success("تمت إضافة الأرشيف بنجاح ✅");
    logAdmin("إضافة أرشيف", { "العنوان": newArchive.title, "المرجع": newArchive.reference, "بواسطة": user?.email || "-" });
    setNewArchive({ title: "", type: "وثيقة", reference: "", date: new Date().toISOString().split("T")[0], from_entity: "", to_entity: "", body: "", department_id: "" });
    setShowAddArchive(false);
    fetchAll();
  };

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const fileName = `staff/${Date.now()}-${file.name}`;
    const { error } = await supabase.storage.from("photos").upload(fileName, file);
    if (error) { toast.error("فشل رفع الصورة"); return; }
    const { data: { publicUrl } } = supabase.storage.from("photos").getPublicUrl(fileName);
    setNewStaff({ ...newStaff, photo_url: publicUrl });
    toast.success("تم رفع الصورة ✅");
  };

  const updateStatus = async (table: string, id: string, status: string) => {
    const { error } = await (supabase.from(table as any) as any).update({ status }).eq("id", id);
    if (error) { toast.error("حدث خطأ"); return; }
    toast.success("تم تحديث الحالة ✅");
    logAdmin("تحديث حالة طلب", { "الجدول": table, "المعرّف": id, "الحالة الجديدة": status, "بواسطة": user?.email || "-" });
    fetchAll();
  };

  const deleteRow = async (table: string, id: string) => {
    if (!confirm("هل أنت متأكد من حذف هذا الطلب؟")) return;
    const { error } = await (supabase.from(table as any) as any).delete().eq("id", id);
    if (error) { toast.error("حدث خطأ في الحذف"); return; }
    toast.success("تم الحذف ✅");
    logAdmin("حذف سجل", { "الجدول": table, "المعرّف": id, "بواسطة": user?.email || "-" });
    fetchAll();
  };

  const handleSaveAnnouncement = async () => {
    if (!editingAnn) return;
    const { error } = await supabase.from("announcements").update({
      title: editingAnn.title, type: editingAnn.type, content: editingAnn.content, date: editingAnn.date,
      department_id: editingAnn.department_id || null,
    }).eq("id", editingAnn.id);
    if (error) { toast.error("حدث خطأ"); return; }
    toast.success("تم تحديث الإعلان ✅");
    setEditingAnn(null);
    fetchAll();
  };

  const handleSaveArchive = async () => {
    if (!editingArc) return;
    const { error } = await supabase.from("archives").update({
      title: editingArc.title, type: editingArc.type, reference: editingArc.reference, date: editingArc.date,
      from_entity: editingArc.from_entity, to_entity: editingArc.to_entity, body: editingArc.body,
      department_id: editingArc.department_id || null,
    }).eq("id", editingArc.id);
    if (error) { toast.error("حدث خطأ"); return; }
    toast.success("تم تحديث الأرشيف ✅");
    setEditingArc(null);
    fetchAll();
  };

  const handleSaveStaff = async () => {
    if (!editingStaff) return;
    const { error } = await supabase.from("staff").update({
      name: editingStaff.name, position: editingStaff.position, department: editingStaff.department,
      phone: editingStaff.phone, email: editingStaff.email, join_date: editingStaff.join_date,
      department_id: editingStaff.department_id || null,
    }).eq("id", editingStaff.id);
    if (error) { toast.error("حدث خطأ"); return; }
    toast.success("تم تحديث المنسوب ✅");
    setEditingStaff(null);
    fetchAll();
  };

  const handleLinkUserDepts = async () => {
    if (!linkEmail || linkDepts.length === 0) { toast.error("يرجى تحديد البريد والأقسام"); return; }
    const uid = await lookupUserId(linkEmail);
    if (!uid) { toast.error("هذا الحساب غير مسجل بعد"); return; }
    // Remove existing links then add new ones
    await supabase.from("user_departments").delete().eq("user_id", uid);
    const inserts = linkDepts.map((deptId) => ({ user_id: uid, department_id: deptId }));
    const { error } = await supabase.from("user_departments").insert(inserts);
    if (error) { toast.error("حدث خطأ"); return; }
    toast.success("تم ربط المستخدم بالأقسام ✅");
    setLinkEmail("");
    setLinkDepts([]);
    fetchUserDeptLinks();
  };

  const stats = [
    { label: "الطلبات", value: applications.length, icon: FileText, color: "text-primary" },
    { label: "الإعلانات", value: announcements.length, icon: Megaphone, color: "text-gold-light" },
    { label: "الأرشيفات", value: archivesList.length, icon: Archive, color: "text-primary" },
    { label: "المنسوبين", value: staffList.length, icon: Users, color: "text-gold-light" },
    { label: "الأقسام", value: departments.length, icon: LayoutGrid, color: "text-primary" },
    { label: "طلبات الجلسات", value: sessionRequests.length, icon: Gavel, color: "text-gold-light" },
    { label: "طلبات الرخص", value: licenseRequests.length, icon: Store, color: "text-primary" },
    { label: "طلبات المذكرات", value: memoRequests.length, icon: ScrollText, color: "text-gold-light" },
  ];

  if (loading) return null;
  if (!canManage) return null;

  // Department select component for reuse
  const DeptSelect = ({ value, onChange, className = "" }: { value: string; onChange: (v: string) => void; className?: string }) => (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger className={`bg-secondary/50 border-border/50 h-9 text-xs ${className}`}><SelectValue placeholder="اختر القسم" /></SelectTrigger>
      <SelectContent>
        <SelectItem value="none">بدون قسم</SelectItem>
        {departments.map((d) => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}
      </SelectContent>
    </Select>
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="bg-primary/10 p-2 rounded-lg"><Settings className="h-6 w-6 text-primary" /></div>
        <h1 className="font-heading text-2xl font-black">لوحة الإدارة</h1>
        {role && <span className="px-3 py-1 rounded-full bg-primary/15 text-primary text-xs font-heading font-bold">{roleLabels[role]}</span>}
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        {stats.map((s, i) => (
          <div key={s.label} className="glass-card rounded-xl p-4 card-hover animate-fade-in" style={{ animationDelay: `${i * 80}ms` }}>
            <div className="flex items-center justify-between mb-2">
              <s.icon className={`h-5 w-5 ${s.color}`} />
              <TrendingUp className="h-3 w-3 text-green-400" />
            </div>
            <p className="text-2xl font-heading font-black">{s.value}</p>
            <p className="text-[10px] text-muted-foreground font-heading">{s.label}</p>
          </div>
        ))}
      </div>

      <Tabs defaultValue="applications" dir="rtl">
        <TabsList className="glass-card border-border/30 font-heading h-auto flex-wrap">
          <TabsTrigger value="applications" className="text-xs data-[state=active]:bg-primary/15 data-[state=active]:text-primary">الطلبات</TabsTrigger>
          <TabsTrigger value="sessions" className="text-xs data-[state=active]:bg-primary/15 data-[state=active]:text-primary">طلبات الجلسات</TabsTrigger>
          <TabsTrigger value="licenses" className="text-xs data-[state=active]:bg-primary/15 data-[state=active]:text-primary">الرخص التجارية</TabsTrigger>
          <TabsTrigger value="memos" className="text-xs data-[state=active]:bg-primary/15 data-[state=active]:text-primary">طلبات المذكرات</TabsTrigger>
          <TabsTrigger value="staff" className="text-xs data-[state=active]:bg-primary/15 data-[state=active]:text-primary">المنسوبين</TabsTrigger>
          <TabsTrigger value="departments" className="text-xs data-[state=active]:bg-primary/15 data-[state=active]:text-primary">الأقسام</TabsTrigger>
          <TabsTrigger value="announcements" className="text-xs data-[state=active]:bg-primary/15 data-[state=active]:text-primary">الإعلانات</TabsTrigger>
          <TabsTrigger value="archives" className="text-xs data-[state=active]:bg-primary/15 data-[state=active]:text-primary">الأرشيفات</TabsTrigger>
          {role === "attorney_general" && (
            <TabsTrigger value="user-depts" className="text-xs data-[state=active]:bg-primary/15 data-[state=active]:text-primary">ربط المستخدمين</TabsTrigger>
          )}
        </TabsList>

        {/* Applications */}
        <TabsContent value="applications">
          <div className="glass-card rounded-xl overflow-auto gold-border mt-4">
            <div className="p-4 border-b border-border/30">
              <h2 className="font-heading font-bold text-sm">جميع الطلبات ({applications.length})</h2>
            </div>
            {applications.length === 0 ? (
              <div className="p-12 text-center"><FileText className="h-10 w-10 text-muted-foreground mx-auto mb-2" /><p className="text-muted-foreground font-heading text-sm">لا توجد طلبات</p></div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow className="bg-primary/5 border-b border-border/30">
                    <TableHead className="text-primary font-heading font-bold text-xs">الاسم</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">Discord</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">الجوال</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">القسم</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">النوع</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">التاريخ</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">الحالة</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">إجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {applications.map((a) => (
                    <TableRow key={a.id} className="border-b border-border/20 hover:bg-secondary/30">
                      <TableCell className="font-heading font-bold text-xs">{a.full_name}</TableCell>
                      <TableCell dir="ltr" className="text-right text-xs font-mono">{a.national_id}</TableCell>
                      <TableCell dir="ltr" className="text-right text-xs font-mono">{a.phone}</TableCell>
                      <TableCell className="text-xs">{a.department}</TableCell>
                      <TableCell className="text-xs">{a.type}</TableCell>
                      <TableCell className="text-xs text-muted-foreground">{a.date}</TableCell>
                      <TableCell>
                        <Select value={a.status} onValueChange={(v) => updateStatus("applications", a.id, v)}>
                          <SelectTrigger className="h-7 w-28 text-[10px] bg-transparent border-border/30"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="جديد">جديد</SelectItem>
                            <SelectItem value="قيد المراجعة">قيد المراجعة</SelectItem>
                            <SelectItem value="مقبول">مقبول</SelectItem>
                            <SelectItem value="مرفوض">مرفوض</SelectItem>
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell>
                        <Button onClick={() => deleteRow("applications", a.id)} variant="ghost" size="icon" className="h-7 w-7 text-red-400 hover:text-red-300 hover:bg-red-500/10">
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </div>
        </TabsContent>

        {/* Sessions */}
        <TabsContent value="sessions">
          <div className="glass-card rounded-xl overflow-auto gold-border mt-4">
            <div className="p-4 border-b border-border/30">
              <h2 className="font-heading font-bold text-sm">طلبات الجلسات ({sessionRequests.length})</h2>
            </div>
            {sessionRequests.length === 0 ? (
              <div className="p-12 text-center"><Gavel className="h-10 w-10 text-muted-foreground mx-auto mb-2" /><p className="text-muted-foreground font-heading text-sm">لا توجد طلبات جلسات</p></div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow className="bg-primary/5 border-b border-border/30">
                    <TableHead className="text-primary font-heading font-bold text-xs">الاسم</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">Discord</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">رقم القضية</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">السبب</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">التاريخ المفضل</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">الحالة</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">إجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {sessionRequests.map((r) => (
                    <TableRow key={r.id} className="border-b border-border/20 hover:bg-secondary/30">
                      <TableCell className="font-heading font-bold text-xs">{r.full_name}</TableCell>
                      <TableCell dir="ltr" className="text-right text-xs font-mono">{r.national_id}</TableCell>
                      <TableCell className="text-xs font-mono">{r.case_number}</TableCell>
                      <TableCell className="text-xs max-w-[200px] truncate text-muted-foreground">{r.reason}</TableCell>
                      <TableCell className="text-xs">{r.preferred_date}</TableCell>
                      <TableCell>
                        <Select value={r.status} onValueChange={(v) => updateStatus("session_requests", r.id, v)}>
                          <SelectTrigger className="h-7 w-28 text-[10px] bg-transparent border-border/30"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="جديد">جديد</SelectItem>
                            <SelectItem value="مقبول">مقبول</SelectItem>
                            <SelectItem value="مرفوض">مرفوض</SelectItem>
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell>
                        <Button onClick={() => deleteRow("session_requests", r.id)} variant="ghost" size="icon" className="h-7 w-7 text-red-400 hover:text-red-300 hover:bg-red-500/10">
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </div>
        </TabsContent>

        {/* Commercial License Requests */}
        <TabsContent value="licenses">
          <div className="glass-card rounded-xl overflow-auto gold-border mt-4">
            <div className="p-4 border-b border-border/30">
              <h2 className="font-heading font-bold text-sm">طلبات الرخص التجارية ({licenseRequests.length})</h2>
            </div>
            {licenseRequests.length === 0 ? (
              <div className="p-12 text-center"><Store className="h-10 w-10 text-muted-foreground mx-auto mb-2" /><p className="text-muted-foreground font-heading text-sm">لا توجد طلبات رخص</p></div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow className="bg-primary/5 border-b border-border/30">
                    <TableHead className="text-primary font-heading font-bold text-xs">الاسم</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">Discord</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">الجوال</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">اسم النشاط</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">النوع</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">العنوان</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">رأس المال</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">التاريخ</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">الحالة</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">إجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {licenseRequests.map((l) => (
                    <TableRow key={l.id} className="border-b border-border/20 hover:bg-secondary/30">
                      <TableCell className="font-heading font-bold text-xs">{l.full_name}</TableCell>
                      <TableCell dir="ltr" className="text-right text-xs font-mono">{l.national_id}</TableCell>
                      <TableCell dir="ltr" className="text-right text-xs font-mono">{l.phone}</TableCell>
                      <TableCell className="text-xs">{l.business_name}</TableCell>
                      <TableCell className="text-xs">{l.business_type}</TableCell>
                      <TableCell className="text-xs max-w-[180px] truncate" title={l.address}>{l.address}</TableCell>
                      <TableCell className="text-xs">{l.capital || "-"}</TableCell>
                      <TableCell className="text-xs">{l.date}</TableCell>
                      <TableCell>
                        <Select value={l.status} onValueChange={(v) => updateStatus("commercial_license_requests", l.id, v)}>
                          <SelectTrigger className={`h-7 text-xs w-28 ${statusColors[l.status] || ""}`}><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="جديد">جديد</SelectItem>
                            <SelectItem value="قيد المراجعة">قيد المراجعة</SelectItem>
                            <SelectItem value="مقبول">مقبول</SelectItem>
                            <SelectItem value="مرفوض">مرفوض</SelectItem>
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell>
                        <Button onClick={() => deleteRow("commercial_license_requests", l.id)} variant="ghost" size="icon" className="h-7 w-7 text-red-400 hover:text-red-300 hover:bg-red-500/10">
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </div>
        </TabsContent>

        {/* Memo Requests */}
        <TabsContent value="memos">
          <div className="glass-card rounded-xl overflow-auto gold-border mt-4">
            <div className="p-4 border-b border-border/30">
              <h2 className="font-heading font-bold text-sm">طلبات المذكرات ({memoRequests.length})</h2>
            </div>
            {memoRequests.length === 0 ? (
              <div className="p-12 text-center"><ScrollText className="h-10 w-10 text-muted-foreground mx-auto mb-2" /><p className="text-muted-foreground font-heading text-sm">لا توجد طلبات مذكرات</p></div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow className="bg-primary/5 border-b border-border/30">
                    <TableHead className="text-primary font-heading font-bold text-xs">الاسم</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">Discord</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">الجوال</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">الجهة</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">الموضوع</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">التفاصيل</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">التاريخ</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">الحالة</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">إجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {memoRequests.map((m) => (
                    <TableRow key={m.id} className="border-b border-border/20 hover:bg-secondary/30">
                      <TableCell className="font-heading font-bold text-xs">{m.full_name}</TableCell>
                      <TableCell dir="ltr" className="text-right text-xs font-mono">{m.national_id}</TableCell>
                      <TableCell dir="ltr" className="text-right text-xs font-mono">{m.phone}</TableCell>
                      <TableCell className="text-xs">{m.target_entity}</TableCell>
                      <TableCell className="text-xs">{m.subject}</TableCell>
                      <TableCell className="text-xs max-w-[220px] truncate" title={m.details || ""}>{m.details || "-"}</TableCell>
                      <TableCell className="text-xs">{new Date(m.created_at).toLocaleDateString("ar-SA")}</TableCell>
                      <TableCell>
                        <Select value={m.status} onValueChange={(v) => updateStatus("memo_requests", m.id, v)}>
                          <SelectTrigger className={`h-7 text-xs w-28 ${statusColors[m.status] || ""}`}><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="جديد">جديد</SelectItem>
                            <SelectItem value="قيد المراجعة">قيد المراجعة</SelectItem>
                            <SelectItem value="مقبول">مقبول</SelectItem>
                            <SelectItem value="مرفوض">مرفوض</SelectItem>
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell>
                        <Button onClick={() => deleteRow("memo_requests", m.id)} variant="ghost" size="icon" className="h-7 w-7 text-red-400 hover:text-red-300 hover:bg-red-500/10">
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </div>
        </TabsContent>




        {/* Staff */}
        <TabsContent value="staff">
          <div className="glass-card rounded-xl overflow-auto gold-border mt-4">
            <div className="p-4 border-b border-border/30 flex items-center justify-between">
              <h2 className="font-heading font-bold text-sm">منسوبي العدل ({staffList.length})</h2>
              <Button onClick={() => setShowAddStaff(!showAddStaff)} size="sm" className="gold-gradient text-primary-foreground font-heading font-bold text-xs">
                <UserPlus className="h-4 w-4 ml-1" />إضافة منسوب
              </Button>
            </div>

            {showAddStaff && (
              <div className="p-4 border-b border-border/30 bg-secondary/30 animate-fade-in">
                <div className="grid gap-3 md:grid-cols-3">
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">الاسم *</Label>
                    <Input value={newStaff.name} onChange={(e) => setNewStaff({ ...newStaff, name: e.target.value })} placeholder="الاسم الكامل" className="bg-secondary/50 border-border/50 h-9 text-xs" />
                  </div>
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">المنصب *</Label>
                    <Select value={newStaff.position} onValueChange={(v) => setNewStaff({ ...newStaff, position: v })}>
                      <SelectTrigger className="bg-secondary/50 border-border/50 h-9 text-xs"><SelectValue placeholder="اختر المنصب" /></SelectTrigger>
                      <SelectContent>
                        {POSITIONS.map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">القسم (اسم) *</Label>
                    <Select value={newStaff.department} onValueChange={(v) => setNewStaff({ ...newStaff, department: v })}>
                      <SelectTrigger className="bg-secondary/50 border-border/50 h-9 text-xs"><SelectValue placeholder="اختر القسم" /></SelectTrigger>
                      <SelectContent>
                        {departments.map((d) => <SelectItem key={d.id} value={d.name}>{d.name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">ربط بالقسم</Label>
                    <DeptSelect value={newStaff.department_id || "none"} onChange={(v) => setNewStaff({ ...newStaff, department_id: v === "none" ? "" : v })} />
                  </div>
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">الهاتف *</Label>
                    <Input value={newStaff.phone} onChange={(e) => setNewStaff({ ...newStaff, phone: e.target.value })} placeholder="05XXXXXXXX" className="bg-secondary/50 border-border/50 h-9 text-xs" />
                  </div>
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">البريد *</Label>
                    <Input value={newStaff.email} onChange={(e) => setNewStaff({ ...newStaff, email: e.target.value })} placeholder="email@moj.gov" className="bg-secondary/50 border-border/50 h-9 text-xs" />
                  </div>
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">تاريخ الالتحاق</Label>
                    <Input type="date" value={newStaff.join_date} onChange={(e) => setNewStaff({ ...newStaff, join_date: e.target.value })} className="bg-secondary/50 border-border/50 h-9 text-xs" />
                  </div>
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">صورة المنسوب</Label>
                    <div className="flex items-center gap-2">
                      <label className="cursor-pointer flex items-center gap-1 px-3 py-1.5 rounded-lg bg-primary/10 text-primary text-xs font-heading hover:bg-primary/20 transition-colors">
                        <ImagePlus className="h-3.5 w-3.5" />اختر صورة
                        <input type="file" accept="image/*" onChange={handlePhotoUpload} className="hidden" />
                      </label>
                      {newStaff.photo_url && <img src={newStaff.photo_url} alt="preview" className="w-9 h-9 rounded-full object-cover border border-primary/30" />}
                    </div>
                  </div>
                </div>
                <div className="flex gap-2 mt-3">
                  <Button onClick={handleAddStaff} size="sm" className="gold-gradient text-primary-foreground font-heading font-bold text-xs"><Plus className="h-3 w-3 ml-1" /> إضافة</Button>
                  <Button onClick={() => setShowAddStaff(false)} size="sm" variant="ghost" className="text-xs font-heading">إلغاء</Button>
                </div>
              </div>
            )}

            {editingStaff && (
              <div className="p-4 border-b border-border/30 bg-amber-500/5 animate-fade-in">
                <h3 className="font-heading font-bold text-xs mb-3 text-primary">تعديل المنسوب</h3>
                <div className="grid gap-3 md:grid-cols-3">
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">الاسم</Label>
                    <Input value={editingStaff.name} onChange={(e) => setEditingStaff({ ...editingStaff, name: e.target.value })} className="bg-secondary/50 border-border/50 h-9 text-xs" />
                  </div>
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">المنصب</Label>
                    <Select value={editingStaff.position} onValueChange={(v) => setEditingStaff({ ...editingStaff, position: v })}>
                      <SelectTrigger className="bg-secondary/50 border-border/50 h-9 text-xs"><SelectValue placeholder="اختر المنصب" /></SelectTrigger>
                      <SelectContent>
                        {POSITIONS.map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">القسم</Label>
                    <Input value={editingStaff.department} onChange={(e) => setEditingStaff({ ...editingStaff, department: e.target.value })} className="bg-secondary/50 border-border/50 h-9 text-xs" />
                  </div>
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">ربط بالقسم</Label>
                    <DeptSelect value={editingStaff.department_id || "none"} onChange={(v) => setEditingStaff({ ...editingStaff, department_id: v === "none" ? "" : v })} />
                  </div>
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">الهاتف</Label>
                    <Input value={editingStaff.phone} onChange={(e) => setEditingStaff({ ...editingStaff, phone: e.target.value })} className="bg-secondary/50 border-border/50 h-9 text-xs" />
                  </div>
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">البريد</Label>
                    <Input value={editingStaff.email} onChange={(e) => setEditingStaff({ ...editingStaff, email: e.target.value })} className="bg-secondary/50 border-border/50 h-9 text-xs" />
                  </div>
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">تاريخ الالتحاق</Label>
                    <Input type="date" value={editingStaff.join_date} onChange={(e) => setEditingStaff({ ...editingStaff, join_date: e.target.value })} className="bg-secondary/50 border-border/50 h-9 text-xs" />
                  </div>
                </div>
                <div className="flex gap-2 mt-3">
                  <Button onClick={handleSaveStaff} size="sm" className="gold-gradient text-primary-foreground font-heading font-bold text-xs"><Check className="h-3 w-3 ml-1" /> حفظ</Button>
                  <Button onClick={() => setEditingStaff(null)} size="sm" variant="ghost" className="text-xs font-heading"><X className="h-3 w-3 ml-1" /> إلغاء</Button>
                </div>
              </div>
            )}

            {staffList.length === 0 && !showAddStaff ? (
              <div className="p-12 text-center"><Users className="h-10 w-10 text-muted-foreground mx-auto mb-2" /><p className="text-muted-foreground font-heading text-sm">لا يوجد منسوبين</p></div>
            ) : (
              <div className="grid gap-3 p-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
                {staffList.map((s) => {
                  const staffRole = userRoles.find((ur) => ur._email === s.email);
                  return (
                    <div key={s.id} className="glass-card rounded-xl p-4 group">
                      <div className="flex items-center gap-3">
                        {s.photo_url ? (
                          <img src={s.photo_url} alt={s.name} className="w-12 h-12 rounded-full object-cover border border-primary/30" />
                        ) : (
                          <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center border border-primary/30"><Users className="h-5 w-5 text-primary" /></div>
                        )}
                        <div className="flex-1 min-w-0">
                          <p className="font-heading font-bold text-xs truncate">{s.name}</p>
                          <p className="text-[10px] text-muted-foreground">{s.position} — {s.department}</p>
                          {s.department_id && <p className="text-[10px] text-amber-400">{deptName(s.department_id)}</p>}
                          <p className="text-[10px] text-muted-foreground" dir="ltr">{s.email}</p>
                        </div>
                        <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <Button onClick={() => setEditingStaff(s)} size="sm" variant="ghost" className="text-primary hover:text-primary hover:bg-primary/10 h-8 w-8 p-0">
                            <Pencil className="h-3.5 w-3.5" />
                          </Button>
                          <Button onClick={async () => { await supabase.from("staff").delete().eq("id", s.id); toast.success("تم حذف المنسوب"); fetchAll(); }} size="sm" variant="ghost" className="text-red-400 hover:text-red-300 hover:bg-red-500/10 h-8 w-8 p-0">
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      </div>
                      {role === "attorney_general" && (
                        <div className="mt-3 pt-3 border-t border-border/20">
                          <div className="flex items-center gap-2">
                            <Shield className="h-3.5 w-3.5 text-primary" />
                            <span className="text-[10px] font-heading font-bold text-muted-foreground">الرتبة:</span>
                            <Select
                              value={staffRole?.role || "none"}
                              onValueChange={async (v) => {
                                const uid = await lookupUserId(s.email);
                                if (!uid) { toast.error("هذا المنسوب لم يسجل حساب بعد"); return; }
                                if (v === "none") {
                                  await supabase.from("user_roles").delete().eq("user_id", uid);
                                } else {
                                  const { data: existing } = await supabase.from("user_roles").select("id").eq("user_id", uid).maybeSingle();
                                  if (existing) {
                                    await supabase.from("user_roles").update({ role: v as AppRole }).eq("user_id", uid);
                                  } else {
                                    await supabase.from("user_roles").insert({ user_id: uid, role: v as AppRole });
                                  }
                                }
                                toast.success("تم تحديث الرتبة ✅");
                                logAdmin("تغيير رتبة", { "المنسوب": s.name, "البريد": s.email, "الرتبة الجديدة": v === "none" ? "بدون رتبة" : roleLabels[v as AppRole], "بواسطة": user?.email || "-" });
                                fetchRoles();
                              }}
                            >
                              <SelectTrigger className="h-7 flex-1 text-[10px] bg-transparent border-border/30"><SelectValue placeholder="بدون رتبة" /></SelectTrigger>
                              <SelectContent>
                                <SelectItem value="none">بدون رتبة</SelectItem>
                                <SelectItem value="law">Law</SelectItem>
                                <SelectItem value="judge">Judge</SelectItem>
                                <SelectItem value="deputy_attorney_general">Deputy Attorney General</SelectItem>
                                <SelectItem value="attorney_general">Attorney General</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </TabsContent>

        {/* Departments */}
        <TabsContent value="departments">
          <div className="glass-card rounded-xl overflow-auto gold-border mt-4">
            <div className="p-4 border-b border-border/30 flex items-center justify-between">
              <h2 className="font-heading font-bold text-sm">أقسام الوزارة ({departments.length})</h2>
              <Button onClick={() => setShowAddDept(!showAddDept)} size="sm" className="gold-gradient text-primary-foreground font-heading font-bold text-xs">
                <Plus className="h-4 w-4 ml-1" />إضافة قسم
              </Button>
            </div>

            {showAddDept && (
              <div className="p-4 border-b border-border/30 bg-secondary/30 animate-fade-in">
                <div className="grid gap-3 md:grid-cols-2">
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">اسم القسم *</Label>
                    <Input value={newDept.name} onChange={(e) => setNewDept({ ...newDept, name: e.target.value })} placeholder="مثال: الشؤون المدنية" className="bg-secondary/50 border-border/50 h-9 text-xs" />
                  </div>
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">رئيس القسم *</Label>
                    <Input value={newDept.head} onChange={(e) => setNewDept({ ...newDept, head: e.target.value })} placeholder="المستشار ..." className="bg-secondary/50 border-border/50 h-9 text-xs" />
                  </div>
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">الهاتف *</Label>
                    <Input value={newDept.phone} onChange={(e) => setNewDept({ ...newDept, phone: e.target.value })} placeholder="011-XXXXXXX" className="bg-secondary/50 border-border/50 h-9 text-xs" />
                  </div>
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">الأيقونة</Label>
                    <Select value={newDept.icon} onValueChange={(v) => setNewDept({ ...newDept, icon: v })}>
                      <SelectTrigger className="bg-secondary/50 border-border/50 h-9 text-xs"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Building2">مبنى</SelectItem>
                        <SelectItem value="Scale">ميزان</SelectItem>
                        <SelectItem value="Shield">درع</SelectItem>
                        <SelectItem value="Gavel">مطرقة</SelectItem>
                        <SelectItem value="Users">مستخدمين</SelectItem>
                        <SelectItem value="FileText">ملف</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-1 mt-3">
                  <Label className="font-heading text-xs">الوصف *</Label>
                  <Textarea value={newDept.description} onChange={(e) => setNewDept({ ...newDept, description: e.target.value })} placeholder="وصف مختصر..." rows={2} className="bg-secondary/50 border-border/50 text-xs" />
                </div>
                <div className="flex gap-2 mt-3">
                  <Button onClick={handleAddDept} size="sm" className="gold-gradient text-primary-foreground font-heading font-bold text-xs"><Plus className="h-3 w-3 ml-1" /> إضافة</Button>
                  <Button onClick={() => setShowAddDept(false)} size="sm" variant="ghost" className="text-xs font-heading">إلغاء</Button>
                </div>
              </div>
            )}

            {departments.length === 0 && !showAddDept ? (
              <div className="p-12 text-center"><LayoutGrid className="h-10 w-10 text-muted-foreground mx-auto mb-2" /><p className="text-muted-foreground font-heading text-sm">لا توجد أقسام</p></div>
            ) : (
              <div className="grid gap-3 p-4 grid-cols-1 sm:grid-cols-2">
                {departments.map((d) => (
                  <div key={d.id} className="glass-card rounded-xl p-4 group">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="font-heading font-bold text-sm">{d.name}</h3>
                        <p className="text-[10px] text-muted-foreground mt-1">{d.description}</p>
                        <p className="text-[10px] text-primary mt-2 font-heading">رئيس القسم: {d.head}</p>
                        <p className="text-[10px] text-muted-foreground" dir="ltr">{d.phone}</p>
                      </div>
                      <Button onClick={async () => { await supabase.from("departments").delete().eq("id", d.id); toast.success("تم حذف القسم"); fetchAll(); }} size="sm" variant="ghost" className="opacity-0 group-hover:opacity-100 text-red-400 hover:text-red-300 hover:bg-red-500/10 h-8 w-8 p-0">
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </TabsContent>

        {/* Announcements */}
        <TabsContent value="announcements">
          <div className="glass-card rounded-xl overflow-auto gold-border mt-4">
            <div className="p-4 border-b border-border/30 flex items-center justify-between">
              <h2 className="font-heading font-bold text-sm">الإعلانات ({announcements.length})</h2>
              <Button onClick={() => setShowAddAnnouncement(!showAddAnnouncement)} size="sm" className="gold-gradient text-primary-foreground font-heading font-bold text-xs">
                <Plus className="h-4 w-4 ml-1" />إضافة إعلان
              </Button>
            </div>

            {showAddAnnouncement && (
              <div className="p-4 border-b border-border/30 bg-secondary/30 animate-fade-in">
                <div className="grid gap-3 md:grid-cols-2">
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">العنوان *</Label>
                    <Input value={newAnnouncement.title} onChange={(e) => setNewAnnouncement({ ...newAnnouncement, title: e.target.value })} placeholder="عنوان الإعلان" className="bg-secondary/50 border-border/50 h-9 text-xs" />
                  </div>
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">النوع</Label>
                    <Select value={newAnnouncement.type} onValueChange={(v) => setNewAnnouncement({ ...newAnnouncement, type: v })}>
                      <SelectTrigger className="bg-secondary/50 border-border/50 h-9 text-xs"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="إعلان">إعلان</SelectItem>
                        <SelectItem value="استدعاء">استدعاء</SelectItem>
                        <SelectItem value="تعميم">تعميم</SelectItem>
                        <SelectItem value="قرار">قرار</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">التاريخ</Label>
                    <Input type="date" value={newAnnouncement.date} onChange={(e) => setNewAnnouncement({ ...newAnnouncement, date: e.target.value })} className="bg-secondary/50 border-border/50 h-9 text-xs" />
                  </div>
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">القسم</Label>
                    <DeptSelect value={newAnnouncement.department_id || "none"} onChange={(v) => setNewAnnouncement({ ...newAnnouncement, department_id: v === "none" ? "" : v })} />
                  </div>
                </div>
                <div className="space-y-1 mt-3">
                  <Label className="font-heading text-xs">المحتوى *</Label>
                  <Textarea value={newAnnouncement.content} onChange={(e) => setNewAnnouncement({ ...newAnnouncement, content: e.target.value })} placeholder="محتوى الإعلان..." rows={3} className="bg-secondary/50 border-border/50 text-xs" />
                </div>
                <div className="flex gap-2 mt-3">
                  <Button onClick={handleAddAnnouncement} size="sm" className="gold-gradient text-primary-foreground font-heading font-bold text-xs"><Plus className="h-3 w-3 ml-1" /> إضافة</Button>
                  <Button onClick={() => setShowAddAnnouncement(false)} size="sm" variant="ghost" className="text-xs font-heading">إلغاء</Button>
                </div>
              </div>
            )}

            {editingAnn && (
              <div className="p-4 border-b border-border/30 bg-amber-500/5 animate-fade-in">
                <h3 className="font-heading font-bold text-xs mb-3 text-primary">تعديل الإعلان</h3>
                <div className="grid gap-3 md:grid-cols-2">
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">العنوان</Label>
                    <Input value={editingAnn.title} onChange={(e) => setEditingAnn({ ...editingAnn, title: e.target.value })} className="bg-secondary/50 border-border/50 h-9 text-xs" />
                  </div>
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">النوع</Label>
                    <Select value={editingAnn.type} onValueChange={(v) => setEditingAnn({ ...editingAnn, type: v })}>
                      <SelectTrigger className="bg-secondary/50 border-border/50 h-9 text-xs"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="إعلان">إعلان</SelectItem>
                        <SelectItem value="استدعاء">استدعاء</SelectItem>
                        <SelectItem value="تعميم">تعميم</SelectItem>
                        <SelectItem value="قرار">قرار</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">التاريخ</Label>
                    <Input type="date" value={editingAnn.date} onChange={(e) => setEditingAnn({ ...editingAnn, date: e.target.value })} className="bg-secondary/50 border-border/50 h-9 text-xs" />
                  </div>
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">القسم</Label>
                    <DeptSelect value={editingAnn.department_id || "none"} onChange={(v) => setEditingAnn({ ...editingAnn, department_id: v === "none" ? null : v })} />
                  </div>
                </div>
                <div className="space-y-1 mt-3">
                  <Label className="font-heading text-xs">المحتوى</Label>
                  <Textarea value={editingAnn.content} onChange={(e) => setEditingAnn({ ...editingAnn, content: e.target.value })} rows={3} className="bg-secondary/50 border-border/50 text-xs" />
                </div>
                <div className="flex gap-2 mt-3">
                  <Button onClick={handleSaveAnnouncement} size="sm" className="gold-gradient text-primary-foreground font-heading font-bold text-xs"><Check className="h-3 w-3 ml-1" /> حفظ</Button>
                  <Button onClick={() => setEditingAnn(null)} size="sm" variant="ghost" className="text-xs font-heading"><X className="h-3 w-3 ml-1" /> إلغاء</Button>
                </div>
              </div>
            )}

            {announcements.length === 0 && !showAddAnnouncement ? (
              <div className="p-12 text-center"><Megaphone className="h-10 w-10 text-muted-foreground mx-auto mb-2" /><p className="text-muted-foreground font-heading text-sm">لا توجد إعلانات</p></div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow className="bg-primary/5 border-b border-border/30">
                    <TableHead className="text-primary font-heading font-bold text-xs">العنوان</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">النوع</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">القسم</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">التاريخ</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">المحتوى</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">إجراء</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {announcements.map((a) => (
                    <TableRow key={a.id} className="border-b border-border/20 hover:bg-secondary/30">
                      <TableCell className="font-heading font-bold text-xs">{a.title}</TableCell>
                      <TableCell><span className="px-2 py-0.5 rounded-full bg-primary/10 text-primary text-[10px] font-heading">{a.type}</span></TableCell>
                      <TableCell className="text-xs text-amber-400">{a.department_id ? deptName(a.department_id) : "—"}</TableCell>
                      <TableCell className="text-xs text-muted-foreground">{a.date}</TableCell>
                      <TableCell className="max-w-xs truncate text-xs text-muted-foreground">{a.content}</TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          <Button onClick={() => setEditingAnn(a)} size="sm" variant="ghost" className="text-primary hover:text-primary hover:bg-primary/10 h-7 w-7 p-0">
                            <Pencil className="h-3 w-3" />
                          </Button>
                          <Button onClick={async () => { await supabase.from("announcements").delete().eq("id", a.id); toast.success("تم الحذف"); fetchAll(); }} size="sm" variant="ghost" className="text-red-400 hover:text-red-300 hover:bg-red-500/10 h-7 w-7 p-0">
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </div>
        </TabsContent>

        {/* Archives */}
        <TabsContent value="archives">
          <div className="glass-card rounded-xl overflow-auto gold-border mt-4">
            <div className="p-4 border-b border-border/30 flex items-center justify-between">
              <h2 className="font-heading font-bold text-sm">جميع الأرشيفات ({archivesList.length})</h2>
              <Button onClick={() => setShowAddArchive(!showAddArchive)} size="sm" className="gold-gradient text-primary-foreground font-heading font-bold text-xs">
                <Plus className="h-4 w-4 ml-1" />إضافة أرشيف
              </Button>
            </div>

            {showAddArchive && (
              <div className="p-4 border-b border-border/30 bg-secondary/30 animate-fade-in">
                <div className="grid gap-3 md:grid-cols-3">
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">العنوان *</Label>
                    <Input value={newArchive.title} onChange={(e) => setNewArchive({ ...newArchive, title: e.target.value })} placeholder="عنوان الوثيقة" className="bg-secondary/50 border-border/50 h-9 text-xs" />
                  </div>
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">النوع</Label>
                    <Select value={newArchive.type} onValueChange={(v) => setNewArchive({ ...newArchive, type: v })}>
                      <SelectTrigger className="bg-secondary/50 border-border/50 h-9 text-xs"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="وثيقة">وثيقة</SelectItem>
                        <SelectItem value="قرار">قرار</SelectItem>
                        <SelectItem value="تعميم">تعميم</SelectItem>
                        <SelectItem value="خطاب">خطاب</SelectItem>
                        <SelectItem value="محضر">محضر</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">المرجع *</Label>
                    <Input value={newArchive.reference} onChange={(e) => setNewArchive({ ...newArchive, reference: e.target.value })} placeholder="رقم المرجع" className="bg-secondary/50 border-border/50 h-9 text-xs" />
                  </div>
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">التاريخ</Label>
                    <Input type="date" value={newArchive.date} onChange={(e) => setNewArchive({ ...newArchive, date: e.target.value })} className="bg-secondary/50 border-border/50 h-9 text-xs" />
                  </div>
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">القسم</Label>
                    <DeptSelect value={newArchive.department_id || "none"} onChange={(v) => setNewArchive({ ...newArchive, department_id: v === "none" ? "" : v })} />
                  </div>
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">من جهة</Label>
                    <Input value={newArchive.from_entity} onChange={(e) => setNewArchive({ ...newArchive, from_entity: e.target.value })} placeholder="الجهة المرسلة" className="bg-secondary/50 border-border/50 h-9 text-xs" />
                  </div>
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">إلى جهة</Label>
                    <Input value={newArchive.to_entity} onChange={(e) => setNewArchive({ ...newArchive, to_entity: e.target.value })} placeholder="الجهة المستلمة" className="bg-secondary/50 border-border/50 h-9 text-xs" />
                  </div>
                </div>
                <div className="space-y-1 mt-3">
                  <Label className="font-heading text-xs">المحتوى</Label>
                  <Textarea value={newArchive.body} onChange={(e) => setNewArchive({ ...newArchive, body: e.target.value })} placeholder="نص الوثيقة..." rows={3} className="bg-secondary/50 border-border/50 text-xs" />
                </div>
                <div className="flex gap-2 mt-3">
                  <Button onClick={handleAddArchive} size="sm" className="gold-gradient text-primary-foreground font-heading font-bold text-xs"><Plus className="h-3 w-3 ml-1" /> إضافة</Button>
                  <Button onClick={() => setShowAddArchive(false)} size="sm" variant="ghost" className="text-xs font-heading">إلغاء</Button>
                </div>
              </div>
            )}

            {editingArc && (
              <div className="p-4 border-b border-border/30 bg-amber-500/5 animate-fade-in">
                <h3 className="font-heading font-bold text-xs mb-3 text-primary">تعديل الأرشيف</h3>
                <div className="grid gap-3 md:grid-cols-3">
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">العنوان</Label>
                    <Input value={editingArc.title} onChange={(e) => setEditingArc({ ...editingArc, title: e.target.value })} className="bg-secondary/50 border-border/50 h-9 text-xs" />
                  </div>
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">النوع</Label>
                    <Select value={editingArc.type} onValueChange={(v) => setEditingArc({ ...editingArc, type: v })}>
                      <SelectTrigger className="bg-secondary/50 border-border/50 h-9 text-xs"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="وثيقة">وثيقة</SelectItem>
                        <SelectItem value="قرار">قرار</SelectItem>
                        <SelectItem value="تعميم">تعميم</SelectItem>
                        <SelectItem value="خطاب">خطاب</SelectItem>
                        <SelectItem value="محضر">محضر</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">المرجع</Label>
                    <Input value={editingArc.reference} onChange={(e) => setEditingArc({ ...editingArc, reference: e.target.value })} className="bg-secondary/50 border-border/50 h-9 text-xs" />
                  </div>
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">التاريخ</Label>
                    <Input type="date" value={editingArc.date} onChange={(e) => setEditingArc({ ...editingArc, date: e.target.value })} className="bg-secondary/50 border-border/50 h-9 text-xs" />
                  </div>
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">القسم</Label>
                    <DeptSelect value={editingArc.department_id || "none"} onChange={(v) => setEditingArc({ ...editingArc, department_id: v === "none" ? null : v })} />
                  </div>
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">من جهة</Label>
                    <Input value={editingArc.from_entity || ""} onChange={(e) => setEditingArc({ ...editingArc, from_entity: e.target.value })} className="bg-secondary/50 border-border/50 h-9 text-xs" />
                  </div>
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">إلى جهة</Label>
                    <Input value={editingArc.to_entity || ""} onChange={(e) => setEditingArc({ ...editingArc, to_entity: e.target.value })} className="bg-secondary/50 border-border/50 h-9 text-xs" />
                  </div>
                </div>
                <div className="space-y-1 mt-3">
                  <Label className="font-heading text-xs">المحتوى</Label>
                  <Textarea value={editingArc.body || ""} onChange={(e) => setEditingArc({ ...editingArc, body: e.target.value })} rows={3} className="bg-secondary/50 border-border/50 text-xs" />
                </div>
                <div className="flex gap-2 mt-3">
                  <Button onClick={handleSaveArchive} size="sm" className="gold-gradient text-primary-foreground font-heading font-bold text-xs"><Check className="h-3 w-3 ml-1" /> حفظ</Button>
                  <Button onClick={() => setEditingArc(null)} size="sm" variant="ghost" className="text-xs font-heading"><X className="h-3 w-3 ml-1" /> إلغاء</Button>
                </div>
              </div>
            )}

            {archivesList.length === 0 && !showAddArchive ? (
              <div className="p-12 text-center"><Archive className="h-10 w-10 text-muted-foreground mx-auto mb-2" /><p className="text-muted-foreground font-heading text-sm">لا توجد أرشيفات</p></div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow className="bg-primary/5 border-b border-border/30">
                    <TableHead className="text-primary font-heading font-bold text-xs">العنوان</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">النوع</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">القسم</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">المرجع</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">من</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">إلى</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">التاريخ</TableHead>
                    <TableHead className="text-primary font-heading font-bold text-xs">إجراء</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {archivesList.map((a) => (
                    <TableRow key={a.id} className="border-b border-border/20 hover:bg-secondary/30">
                      <TableCell className="font-heading font-bold text-xs">{a.title}</TableCell>
                      <TableCell><span className="px-2 py-0.5 rounded-full bg-primary/10 text-primary text-[10px] font-heading">{a.type}</span></TableCell>
                      <TableCell className="text-xs text-amber-400">{a.department_id ? deptName(a.department_id) : "—"}</TableCell>
                      <TableCell className="text-xs font-mono text-muted-foreground">{a.reference}</TableCell>
                      <TableCell className="text-xs text-muted-foreground">{a.from_entity}</TableCell>
                      <TableCell className="text-xs text-muted-foreground">{a.to_entity}</TableCell>
                      <TableCell className="text-xs text-muted-foreground">{a.date}</TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          <Button onClick={() => setEditingArc(a)} size="sm" variant="ghost" className="text-primary hover:text-primary hover:bg-primary/10 h-7 w-7 p-0">
                            <Pencil className="h-3 w-3" />
                          </Button>
                          <Button onClick={async () => { await supabase.from("archives").delete().eq("id", a.id); toast.success("تم الحذف"); fetchAll(); }} size="sm" variant="ghost" className="text-red-400 hover:text-red-300 hover:bg-red-500/10 h-7 w-7 p-0">
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </div>
        </TabsContent>

        {/* User-Department Linking (AG only) */}
        {role === "attorney_general" && (
          <TabsContent value="user-depts">
            <div className="glass-card rounded-xl overflow-auto gold-border mt-4">
              <div className="p-4 border-b border-border/30">
                <h2 className="font-heading font-bold text-sm flex items-center gap-2"><Link2 className="h-4 w-4 text-primary" /> ربط المستخدمين بالأقسام</h2>
              </div>

              <div className="p-4 border-b border-border/30 bg-secondary/30">
                <div className="grid gap-3 md:grid-cols-2">
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">البريد الإلكتروني *</Label>
                    <Input value={linkEmail} onChange={(e) => setLinkEmail(e.target.value)} placeholder="email@moj.gov" className="bg-secondary/50 border-border/50 h-9 text-xs" />
                  </div>
                  <div className="space-y-1">
                    <Label className="font-heading text-xs">الأقسام</Label>
                    <div className="flex flex-wrap gap-2 mt-1">
                      {departments.map((d) => (
                        <label key={d.id} className="flex items-center gap-1.5 cursor-pointer">
                          <Checkbox
                            checked={linkDepts.includes(d.id)}
                            onCheckedChange={(checked) => {
                              if (checked) setLinkDepts([...linkDepts, d.id]);
                              else setLinkDepts(linkDepts.filter((id) => id !== d.id));
                            }}
                          />
                          <span className="text-xs font-heading">{d.name}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                </div>
                <Button onClick={handleLinkUserDepts} size="sm" className="mt-3 gold-gradient text-primary-foreground font-heading font-bold text-xs">
                  <Link2 className="h-3 w-3 ml-1" /> ربط
                </Button>
              </div>

              {/* Current links */}
              {userDeptLinks.length > 0 && (
                <div className="p-4">
                  <h3 className="font-heading font-bold text-xs mb-3 text-primary">الربط الحالي</h3>
                  <div className="space-y-2">
                    {(() => {
                      const grouped: Record<string, string[]> = {};
                      userDeptLinks.forEach((ud) => {
                        if (!grouped[ud._email]) grouped[ud._email] = [];
                        grouped[ud._email].push(deptName(ud.department_id));
                      });
                      return Object.entries(grouped).map(([email, depts]) => (
                        <div key={email} className="glass-card rounded-lg p-3 flex items-center justify-between">
                          <div>
                            <p className="font-heading font-bold text-xs" dir="ltr">{email}</p>
                            <div className="flex flex-wrap gap-1 mt-1">
                              {depts.map((d) => (
                                <span key={d} className="px-2 py-0.5 rounded-full bg-primary/10 text-primary text-[10px] font-heading">{d}</span>
                              ))}
                            </div>
                          </div>
                          <Button onClick={async () => {
                            const link = userDeptLinks.find((ud) => ud._email === email);
                            if (link) {
                              await supabase.from("user_departments").delete().eq("user_id", link.user_id);
                              toast.success("تم إلغاء الربط");
                              fetchUserDeptLinks();
                            }
                          }} size="sm" variant="ghost" className="text-red-400 hover:text-red-300 hover:bg-red-500/10 h-8 w-8 p-0">
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      ));
                    })()}
                  </div>
                </div>
              )}
            </div>
          </TabsContent>
        )}

      </Tabs>
    </div>
  );
}
