
-- Role enum
CREATE TYPE public.app_role AS ENUM ('law', 'judge', 'attorney_general', 'deputy_attorney_general');

-- Profiles table
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT NOT NULL DEFAULT '',
  avatar_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own profile" ON public.profiles FOR SELECT TO authenticated USING (id = auth.uid());
CREATE POLICY "Users can update own profile" ON public.profiles FOR UPDATE TO authenticated USING (id = auth.uid());

-- User roles table
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role app_role NOT NULL,
  UNIQUE (user_id, role)
);

ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- Security definer function to check roles
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role
  )
$$;

-- Function to get user role
CREATE OR REPLACE FUNCTION public.get_user_role(_user_id UUID)
RETURNS app_role
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT role FROM public.user_roles WHERE user_id = _user_id LIMIT 1
$$;

-- RLS for user_roles
CREATE POLICY "Users can view own role" ON public.user_roles FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "Attorney General can manage roles" ON public.user_roles FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'attorney_general'));

-- Departments table
CREATE TABLE public.departments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  icon TEXT NOT NULL DEFAULT 'Building2',
  head TEXT NOT NULL DEFAULT '',
  phone TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.departments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can view departments" ON public.departments FOR SELECT USING (true);
CREATE POLICY "Judges+ can manage departments" ON public.departments FOR ALL TO authenticated USING (
  public.has_role(auth.uid(), 'attorney_general') OR 
  public.has_role(auth.uid(), 'deputy_attorney_general') OR 
  public.has_role(auth.uid(), 'judge')
);

-- Staff table
CREATE TABLE public.staff (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  position TEXT NOT NULL DEFAULT '',
  department TEXT NOT NULL DEFAULT '',
  phone TEXT NOT NULL DEFAULT '',
  email TEXT NOT NULL DEFAULT '',
  join_date TEXT NOT NULL DEFAULT '',
  photo_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.staff ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can view staff" ON public.staff FOR SELECT USING (true);
CREATE POLICY "Judges+ can manage staff" ON public.staff FOR ALL TO authenticated USING (
  public.has_role(auth.uid(), 'attorney_general') OR 
  public.has_role(auth.uid(), 'deputy_attorney_general') OR 
  public.has_role(auth.uid(), 'judge')
);

-- Announcements table
CREATE TABLE public.announcements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'إعلان',
  date TEXT NOT NULL DEFAULT '',
  content TEXT NOT NULL DEFAULT '',
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.announcements ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can view announcements" ON public.announcements FOR SELECT USING (true);
CREATE POLICY "Judges+ can manage announcements" ON public.announcements FOR ALL TO authenticated USING (
  public.has_role(auth.uid(), 'attorney_general') OR 
  public.has_role(auth.uid(), 'deputy_attorney_general') OR 
  public.has_role(auth.uid(), 'judge')
);

-- Archives table
CREATE TABLE public.archives (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'وثيقة',
  date TEXT NOT NULL DEFAULT '',
  reference TEXT NOT NULL DEFAULT '',
  from_entity TEXT,
  to_entity TEXT,
  body TEXT,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.archives ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can view archives" ON public.archives FOR SELECT USING (true);
CREATE POLICY "Judges+ can manage archives" ON public.archives FOR ALL TO authenticated USING (
  public.has_role(auth.uid(), 'attorney_general') OR 
  public.has_role(auth.uid(), 'deputy_attorney_general') OR 
  public.has_role(auth.uid(), 'judge')
);

-- Applications table
CREATE TABLE public.applications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name TEXT NOT NULL,
  national_id TEXT NOT NULL,
  phone TEXT NOT NULL,
  department TEXT NOT NULL DEFAULT '',
  type TEXT NOT NULL DEFAULT '',
  message TEXT,
  date TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'جديد',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.applications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can insert applications" ON public.applications FOR INSERT WITH CHECK (true);
CREATE POLICY "Authenticated can view applications" ON public.applications FOR SELECT TO authenticated USING (
  public.has_role(auth.uid(), 'attorney_general') OR 
  public.has_role(auth.uid(), 'deputy_attorney_general') OR 
  public.has_role(auth.uid(), 'judge')
);
CREATE POLICY "Judges+ can update applications" ON public.applications FOR UPDATE TO authenticated USING (
  public.has_role(auth.uid(), 'attorney_general') OR 
  public.has_role(auth.uid(), 'deputy_attorney_general') OR 
  public.has_role(auth.uid(), 'judge')
);

-- Session requests table
CREATE TABLE public.session_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name TEXT NOT NULL,
  national_id TEXT NOT NULL,
  phone TEXT NOT NULL,
  case_number TEXT NOT NULL DEFAULT '',
  reason TEXT NOT NULL DEFAULT '',
  preferred_date TEXT NOT NULL DEFAULT '',
  date TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'جديد',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.session_requests ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can insert session requests" ON public.session_requests FOR INSERT WITH CHECK (true);
CREATE POLICY "Authenticated can view session requests" ON public.session_requests FOR SELECT TO authenticated USING (
  public.has_role(auth.uid(), 'attorney_general') OR 
  public.has_role(auth.uid(), 'deputy_attorney_general') OR 
  public.has_role(auth.uid(), 'judge')
);
CREATE POLICY "Judges+ can update session requests" ON public.session_requests FOR UPDATE TO authenticated USING (
  public.has_role(auth.uid(), 'attorney_general') OR 
  public.has_role(auth.uid(), 'deputy_attorney_general') OR 
  public.has_role(auth.uid(), 'judge')
);

-- Trigger to create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'full_name', ''));
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Insert default departments
INSERT INTO public.departments (name, description, icon, head, phone) VALUES
  ('الغرف التجارية', 'إدارة وتنظيم الشؤون التجارية والنزاعات التجارية وتسجيل الشركات', 'Building2', 'المستشار فهد العمري', '011-4567891'),
  ('الشؤون القانونية', 'تقديم الاستشارات القانونية وصياغة التشريعات ومراجعة العقود الحكومية', 'Scale', 'المستشارة نورة السعيد', '011-4567892'),
  ('نقابة المحامين', 'تنظيم مهنة المحاماة وإصدار التراخيص والرقابة على أداء المحامين', 'Gavel', 'المستشار خالد المنصور', '011-4567893');

-- Storage bucket for photos
INSERT INTO storage.buckets (id, name, public) VALUES ('photos', 'photos', true);

CREATE POLICY "Anyone can view photos" ON storage.objects FOR SELECT USING (bucket_id = 'photos');
CREATE POLICY "Authenticated can upload photos" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'photos');
CREATE POLICY "Authenticated can delete photos" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'photos');
