import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/AppSidebar";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { LogIn, LogOut } from "lucide-react";
import { useNavigate } from "react-router-dom";

export function AppLayout({ children }: { children: React.ReactNode }) {
  const { user, roleName, signOut } = useAuth();
  const navigate = useNavigate();

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full">
        <AppSidebar />
        <div className="flex-1 flex flex-col min-w-0">
          <header className="h-12 flex items-center justify-between border-b border-border/50 bg-card/50 backdrop-blur-md px-4 sticky top-0 z-10">
            <div className="flex items-center">
              <SidebarTrigger className="ml-3 text-muted-foreground hover:text-primary transition-colors" />
              <div className="flex items-center gap-3 mr-3">
                <div className="w-1.5 h-1.5 rounded-full bg-primary pulse-dot" />
                <h1 className="font-heading text-xs font-bold text-foreground/80 tracking-wide">
                  Department of Justice — وزارة العدل
                </h1>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {user ? (
                <>
                  {roleName && (
                    <span className="px-2 py-0.5 rounded-full bg-primary/15 text-primary text-[10px] font-heading font-bold">
                      {roleName}
                    </span>
                  )}
                  <Button onClick={async () => { await signOut(); navigate("/"); }} variant="ghost" size="sm" className="text-xs font-heading text-muted-foreground hover:text-red-400">
                    <LogOut className="h-3.5 w-3.5 ml-1" />
                    خروج
                  </Button>
                </>
              ) : (
                <Button onClick={() => navigate("/login")} variant="ghost" size="sm" className="text-xs font-heading text-primary">
                  <LogIn className="h-3.5 w-3.5 ml-1" />
                  تسجيل الدخول
                </Button>
              )}
            </div>
          </header>
          <main className="flex-1 p-6 grid-bg">{children}</main>
        </div>
      </div>
    </SidebarProvider>
  );
}
