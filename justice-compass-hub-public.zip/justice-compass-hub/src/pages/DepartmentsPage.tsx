import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { departmentIcons } from "@/lib/icons";
import { Phone, LayoutGrid, User } from "lucide-react";

export default function DepartmentsPage() {
  const [departments, setDepartments] = useState<any[]>([]);

  useEffect(() => {
    supabase.from("departments").select("*").order("created_at", { ascending: true })
      .then(({ data }) => setDepartments(data || []));
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="bg-primary/10 p-2 rounded-lg"><LayoutGrid className="h-6 w-6 text-primary" /></div>
        <h1 className="font-heading text-2xl font-black">أقسام الوزارة</h1>
      </div>

      {departments.length === 0 ? (
        <div className="glass-card rounded-xl p-12 text-center">
          <LayoutGrid className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
          <p className="text-muted-foreground font-heading">لا توجد أقسام</p>
        </div>
      ) : (
        <div className="grid gap-5 md:grid-cols-2">
          {departments.map((d, i) => {
            const Icon = departmentIcons[d.icon] || departmentIcons.Shield;
            return (
              <div key={d.id} className="glass-card rounded-xl overflow-hidden card-hover animate-fade-in" style={{ animationDelay: `${i * 100}ms` }}>
                <div className="bg-primary/10 p-4 flex items-center gap-3 border-b border-border/30">
                  <div className="bg-primary/20 p-2 rounded-lg"><Icon className="h-6 w-6 text-primary" /></div>
                  <h2 className="font-heading text-lg font-bold">{d.name}</h2>
                </div>
                <div className="p-5 space-y-3">
                  <p className="text-sm text-muted-foreground">{d.description}</p>
                  <div className="flex flex-col gap-2 text-xs">
                    <div className="flex items-center gap-2"><User className="h-3 w-3 text-primary" /><span className="font-heading font-semibold">{d.head}</span></div>
                    <div className="flex items-center gap-2"><Phone className="h-3 w-3 text-primary" /><span dir="ltr">{d.phone}</span></div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
