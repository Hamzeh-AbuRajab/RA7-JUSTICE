
-- Add department_id to announcements, archives, staff
ALTER TABLE public.announcements ADD COLUMN department_id uuid REFERENCES public.departments(id) ON DELETE SET NULL;
ALTER TABLE public.archives ADD COLUMN department_id uuid REFERENCES public.departments(id) ON DELETE SET NULL;
ALTER TABLE public.staff ADD COLUMN department_id uuid REFERENCES public.departments(id) ON DELETE SET NULL;

-- Add signature_url to staff
ALTER TABLE public.staff ADD COLUMN signature_url text;

-- Create user_departments junction table
CREATE TABLE public.user_departments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  department_id uuid NOT NULL REFERENCES public.departments(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, department_id)
);

ALTER TABLE public.user_departments ENABLE ROW LEVEL SECURITY;

-- AG can manage all user-department links
CREATE POLICY "AG can manage user_departments"
ON public.user_departments FOR ALL TO authenticated
USING (public.has_role(auth.uid(), 'attorney_general'::app_role))
WITH CHECK (public.has_role(auth.uid(), 'attorney_general'::app_role));

-- Deputy AG can view user_departments
CREATE POLICY "Deputy AG can view user_departments"
ON public.user_departments FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'deputy_attorney_general'::app_role));

-- Users can view their own department links
CREATE POLICY "Users can view own departments"
ON public.user_departments FOR SELECT TO authenticated
USING (user_id = auth.uid());

-- Helper function: check if user belongs to a department (or is AG/Deputy)
CREATE OR REPLACE FUNCTION public.user_has_department_access(_user_id uuid, _department_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT 
    _department_id IS NULL
    OR public.has_role(_user_id, 'attorney_general'::app_role)
    OR public.has_role(_user_id, 'deputy_attorney_general'::app_role)
    OR EXISTS (
      SELECT 1 FROM public.user_departments 
      WHERE user_id = _user_id AND department_id = _department_id
    )
$$;
