DROP POLICY IF EXISTS "Judges+ or self can view staff" ON public.staff;
CREATE POLICY "Judges+ or self can view staff" ON public.staff FOR SELECT
USING (
  private.has_role(auth.uid(), 'attorney_general'::app_role)
  OR private.has_role(auth.uid(), 'deputy_attorney_general'::app_role)
  OR private.has_role(auth.uid(), 'judge'::app_role)
  OR lower(email) = lower(coalesce(auth.jwt()->>'email',''))
);