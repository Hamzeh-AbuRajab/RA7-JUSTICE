import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/hooks/useAuth";
import { AppLayout } from "@/components/AppLayout";
import HomePage from "./pages/HomePage";
import AnnouncementsPage from "./pages/AnnouncementsPage";
import DepartmentsPage from "./pages/DepartmentsPage";
import ApplyPage from "./pages/ApplyPage";
import RequestSessionPage from "./pages/RequestSessionPage";
import LicensePage from "./pages/LicensePage";
import MemoPage from "./pages/MemoPage";
import ArchivesPage from "./pages/ArchivesPage";
import TemplatesPage from "./pages/TemplatesPage";
import StaffPage from "./pages/StaffPage";
import BudgetPage from "./pages/BudgetPage";
import AdminPage from "./pages/AdminPage";
import LoginPage from "./pages/LoginPage";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <Routes>
            <Route path="/login" element={<LoginPage />} />
            <Route path="*" element={
              <AppLayout>
                <Routes>
                  <Route path="/" element={<HomePage />} />
                  <Route path="/announcements" element={<AnnouncementsPage />} />
                  <Route path="/departments" element={<DepartmentsPage />} />
                  <Route path="/apply" element={<ApplyPage />} />
                  <Route path="/request-session" element={<RequestSessionPage />} />
                  <Route path="/license" element={<LicensePage />} />
                  <Route path="/memo" element={<MemoPage />} />
                  <Route path="/archives" element={<ArchivesPage />} />
                  <Route path="/templates" element={<TemplatesPage />} />
                  <Route path="/staff" element={<StaffPage />} />
                  <Route path="/budget" element={<BudgetPage />} />
                  <Route path="/admin" element={<AdminPage />} />
                  <Route path="*" element={<NotFound />} />
                </Routes>
              </AppLayout>
            } />
          </Routes>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
