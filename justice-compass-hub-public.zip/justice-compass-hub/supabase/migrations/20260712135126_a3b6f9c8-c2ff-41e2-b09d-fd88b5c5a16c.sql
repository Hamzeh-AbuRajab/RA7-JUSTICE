CREATE TABLE public.memo_requests (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  full_name TEXT NOT NULL,
  national_id TEXT NOT NULL,
  phone TEXT NOT NULL,
  target_entity TEXT NOT NULL,
  subject TEXT NOT NULL,
  details TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.memo_requests TO authenticated;
GRANT INSERT ON public.memo_requests TO anon;
GRANT ALL ON public.memo_requests TO service_role;

ALTER TABLE public.memo_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can submit memo requests"
  ON public.memo_requests FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Staff can view memo requests"
  ON public.memo_requests FOR SELECT
  TO authenticated
  USING (
    private.has_role(auth.uid(), 'judge'::app_role)
    OR private.has_role(auth.uid(), 'deputy_attorney_general'::app_role)
    OR private.has_role(auth.uid(), 'attorney_general'::app_role)
  );

CREATE POLICY "Staff can update memo requests"
  ON public.memo_requests FOR UPDATE
  TO authenticated
  USING (
    private.has_role(auth.uid(), 'judge'::app_role)
    OR private.has_role(auth.uid(), 'deputy_attorney_general'::app_role)
    OR private.has_role(auth.uid(), 'attorney_general'::app_role)
  );

CREATE POLICY "Staff can delete memo requests"
  ON public.memo_requests FOR DELETE
  TO authenticated
  USING (
    private.has_role(auth.uid(), 'judge'::app_role)
    OR private.has_role(auth.uid(), 'deputy_attorney_general'::app_role)
    OR private.has_role(auth.uid(), 'attorney_general'::app_role)
  );

CREATE TRIGGER memo_requests_set_updated_at
  BEFORE UPDATE ON public.memo_requests
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();