import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';
import { createClient } from 'npm:@supabase/supabase-js@2';

const ADMIN_EMAIL = 'admin@mog.gov';
const ADMIN_PASSWORD = 'Admin@12345';
const ADMIN_NAME = 'المدير العام';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  const supabase = createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
  );

  try {
    // Find or create user
    let userId: string | null = null;
    const { data: existing } = await supabase.rpc('find_user_by_email', { _email: ADMIN_EMAIL });
    if (existing) {
      userId = existing as string;
      await supabase.auth.admin.updateUserById(userId, { password: ADMIN_PASSWORD });
    } else {
      const { data: created, error } = await supabase.auth.admin.createUser({
        email: ADMIN_EMAIL,
        password: ADMIN_PASSWORD,
        email_confirm: true,
        user_metadata: { full_name: ADMIN_NAME },
      });
      if (error) throw error;
      userId = created.user!.id;
    }

    // Assign attorney_general role
    await supabase.from('user_roles').upsert(
      { user_id: userId, role: 'attorney_general' },
      { onConflict: 'user_id,role' },
    );

    return new Response(
      JSON.stringify({ ok: true, email: ADMIN_EMAIL, password: ADMIN_PASSWORD, user_id: userId }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
    );
  } catch (e: any) {
    return new Response(JSON.stringify({ error: e?.message || String(e) }), {
      status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
