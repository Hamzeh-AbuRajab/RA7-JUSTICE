import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Users, Phone, Mail, Calendar, Briefcase, Shield, ImagePlus } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

type AppRole = "law" | "judge" | "attorney_general" | "deputy_attorney_general";

const roleLabels: Record<string, string> = {
  law: "Law",
  judge: "Judge",
  deputy_attorney_general: "Deputy Attorney General",
  attorney_general: "Attorney General",
  none: "بدون رتبة",
};

export default function StaffPage() {
  const { role, user, userDepartments } = useAuth();
  const [staffList, setStaff] = useState<any[]>([]);
  const [departments, setDepartments] = useState<any[]>([]);
  const [deptFilter, setDeptFilter] = useState("الكل");
  const [userRoles, setUserRoles] = useState<any[]>([]);

  const canSeeAll = role === "attorney_general" || role === "deputy_attorney_general";

  const fetchStaff = () => {
    supabase.from("staff").select("*").order("created_at", { ascending: true })
      .then(({ data }) => setStaff(data || []));
  };

  const fetchRoles = async () => {
    if (role !== "attorney_general") return;
    const { data } = await supabase.from("user_roles").select("*");
    const enriched = await Promise.all((data || []).map(async (ur) => {
      const { data: res } = await supabase.functions.invoke("admin-user-lookup", {
        body: { op: "email_by_id", user_id: ur.user_id },
      });
      return { ...ur, _email: (res as any)?.email || "" };
    }));
    setUserRoles(enriched);
  };

  useEffect(() => {
    fetchStaff();
    fetchRoles();
    supabase.from("departments").select("id, name").then(({ data }) => setDepartments(data || []));
  }, [role]);

  const deptName = (id: string) => departments.find((d) => d.id === id)?.name || "";

  const handleRoleChange = async (email: string, newRole: string) => {
    const { data: res } = await supabase.functions.invoke("admin-user-lookup", {
      body: { op: "id_by_email", email },
    });
    const uid = (res as any)?.user_id as string | null;
    if (!uid) { toast.error("هذا المنسوب لم يسجل حساب بعد"); return; }
    if (newRole === "none") {
      await supabase.from("user_roles").delete().eq("user_id", uid);
    } else {
      const { data: existing } = await supabase.from("user_roles").select("id").eq("user_id", uid).maybeSingle();
      if (existing) {
        await supabase.from("user_roles").update({ role: newRole as AppRole }).eq("user_id", uid);
      } else {
        await supabase.from("user_roles").insert({ user_id: uid, role: newRole as AppRole });
      }
    }
    toast.success("تم تحديث الرتبة ✅");
    fetchRoles();
  };

  const handleSignatureUpload = async (staffId: string, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const fileName = `signatures/${Date.now()}-${file.name}`;
    const { error } = await supabase.storage.from("photos").upload(fileName, file);
    if (error) { toast.error("فشل رفع التوقيع"); return; }
    const { data: { publicUrl } } = supabase.storage.from("photos").getPublicUrl(fileName);
    await supabase.from("staff").update({ signature_url: publicUrl }).eq("id", staffId);
    toast.success("تم رفع التوقيع ✅");
    fetchStaff();
  };

  let filtered = staffList;
  if (!canSeeAll && userDepartments.length > 0) {
    filtered = filtered.filter((s) => !s.department_id || userDepartments.includes(s.department_id));
  }
  if (deptFilter !== "الكل") filtered = filtered.filter((s) => s.department_id === deptFilter);

  // Check if current user is this staff member (for self-signature upload)
  const isOwnStaff = (s: any) => user?.email && s.email.toLowerCase() === user.email.toLowerCase();

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="bg-primary/10 p-2 rounded-lg"><Users className="h-6 w-6 text-primary" /></div>
        <h1 className="font-heading text-2xl font-black">منسوبي العدل</h1>
      </div>

      {departments.length > 0 && (
        <div className="flex flex-wrap gap-2">
          <button onClick={() => setDeptFilter("الكل")} className={`px-3 py-1.5 rounded-lg text-[10px] font-heading font-bold transition-all ${deptFilter === "الكل" ? "bg-primary/20 text-primary" : "glass-card text-muted-foreground hover:text-foreground"}`}>
            جميع الأقسام
          </button>
          {departments.map((d) => (
            <button key={d.id} onClick={() => setDeptFilter(d.id)} className={`px-3 py-1.5 rounded-lg text-[10px] font-heading font-bold transition-all ${deptFilter === d.id ? "bg-primary/20 text-primary" : "glass-card text-muted-foreground hover:text-foreground"}`}>
              {d.name}
            </button>
          ))}
        </div>
      )}

      {filtered.length === 0 ? (
        <div className="glass-card rounded-xl p-12 text-center">
          <Users className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
          <p className="text-muted-foreground font-heading">لا يوجد منسوبين بعد</p>
        </div>
      ) : (
        <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((s, i) => {
            const staffRole = userRoles.find((ur) => ur._email === s.email);
            return (
              <div key={s.id} className="glass-card rounded-xl overflow-hidden card-hover animate-fade-in" style={{ animationDelay: `${i * 60}ms` }}>
                <div className="bg-primary/10 p-5 flex flex-col items-center border-b border-border/20">
                  {s.photo_url ? (
                    <img src={s.photo_url} alt={s.name} className="w-20 h-20 rounded-full object-cover border-2 border-primary/30 mb-3" />
                  ) : (
                    <div className="w-20 h-20 rounded-full bg-primary/20 flex items-center justify-center mb-3 border-2 border-primary/30">
                      <Users className="h-8 w-8 text-primary" />
                    </div>
                  )}
                  <h3 className="font-heading font-bold text-sm">{s.name}</h3>
                  <span className="px-3 py-0.5 rounded-full bg-primary/15 text-primary text-[10px] font-heading font-bold mt-1">{s.position}</span>
                  {s.department_id && <span className="px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-400 text-[10px] font-heading mt-1">{deptName(s.department_id)}</span>}
                  {staffRole && (
                    <span className="px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-400 text-[10px] font-heading font-bold mt-1">
                      {roleLabels[staffRole.role]}
                    </span>
                  )}
                </div>
                <div className="p-4 space-y-2.5">
                  <div className="flex items-center gap-2 text-xs text-muted-foreground"><Briefcase className="h-3.5 w-3.5 text-primary" /><span>{s.department}</span></div>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground"><Phone className="h-3.5 w-3.5 text-primary" /><span dir="ltr">{s.phone}</span></div>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground"><Mail className="h-3.5 w-3.5 text-primary" /><span dir="ltr">{s.email}</span></div>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground"><Calendar className="h-3.5 w-3.5 text-primary" /><span>{s.join_date}</span></div>

                  {/* Signature section - visible to AG or own staff */}
                  {(role === "attorney_general" || isOwnStaff(s)) && (
                    <div className="pt-2 border-t border-border/20">
                      <p className="text-[10px] font-heading font-bold text-muted-foreground mb-2">التوقيع:</p>
                      {s.signature_url ? (
                        <div className="space-y-2">
                          <img src={s.signature_url} alt="التوقيع" className="h-16 object-contain bg-white/5 rounded-lg p-1" />
                          {isOwnStaff(s) && (
                            <label className="cursor-pointer inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-primary/10 text-primary text-[10px] font-heading hover:bg-primary/20 transition-colors">
                              <ImagePlus className="h-3 w-3" />تغيير التوقيع
                              <input type="file" accept="image/*" onChange={(e) => handleSignatureUpload(s.id, e)} className="hidden" />
                            </label>
                          )}
                        </div>
                      ) : (
                        isOwnStaff(s) && (
                          <label className="cursor-pointer inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-primary/10 text-primary text-[10px] font-heading hover:bg-primary/20 transition-colors">
                            <ImagePlus className="h-3.5 w-3.5" />رفع التوقيع
                            <input type="file" accept="image/*" onChange={(e) => handleSignatureUpload(s.id, e)} className="hidden" />
                          </label>
                        )
                      )}
                    </div>
                  )}

                  {role === "attorney_general" && (
                    <div className="pt-2 border-t border-border/20">
                      <div className="flex items-center gap-2">
                        <Shield className="h-3.5 w-3.5 text-primary" />
                        <span className="text-[10px] font-heading font-bold text-muted-foreground">الرتبة:</span>
                        <Select value={staffRole?.role || "none"} onValueChange={(v) => handleRoleChange(s.email, v)}>
                          <SelectTrigger className="h-7 flex-1 text-[10px] bg-transparent border-border/30"><SelectValue placeholder="بدون رتبة" /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="none">بدون رتبة</SelectItem>
                            <SelectItem value="law">Law</SelectItem>
                            <SelectItem value="judge">Judge</SelectItem>
                            <SelectItem value="deputy_attorney_general">Deputy Attorney General</SelectItem>
                            <SelectItem value="attorney_general">Attorney General</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
