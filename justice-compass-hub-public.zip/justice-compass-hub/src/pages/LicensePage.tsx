import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Store, Send } from "lucide-react";

const BUSINESS_TYPES = [
  "مطعم / مقهى",
  "متجر إلكتروني",
  "عقارات",
  "أخرى",
];

export default function LicensePage() {
  const [form, setForm] = useState({
    fullName: "",
    nationalId: "",
    phone: "",
    businessName: "",
    businessType: "",
    address: "",
    capital: "",
    notes: "",
  });
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.fullName || !form.nationalId || !form.phone || !form.businessName || !form.businessType || !form.address) {
      toast.error("يرجى تعبئة جميع الحقول المطلوبة");
      return;
    }
    setSubmitting(true);
    const { error } = await supabase.from("commercial_license_requests").insert({
      full_name: form.fullName,
      national_id: form.nationalId,
      phone: form.phone,
      business_name: form.businessName,
      business_type: form.businessType,
      address: form.address,
      capital: form.capital || null,
      notes: form.notes || null,
    });
    setSubmitting(false);
    if (error) {
      toast.error("حدث خطأ أثناء الإرسال");
      return;
    }
    toast.success("تم إرسال طلب الرخصة التجارية بنجاح ✅");
    supabase.functions.invoke("discord-notify", {
      body: {
        type: "apply",
        data: {
          "نوع الطلب": "رخصة تجارية",
          "الاسم الكامل": form.fullName,
          "اسم مستخدم Discord": form.nationalId,
          "رقم الجوال": form.phone,
          "اسم النشاط": form.businessName,
          "نوع النشاط": form.businessType,
          "العنوان": form.address,
          "رأس المال": form.capital || "-",
          "ملاحظات": form.notes || "-",
        },
      },
    }).catch(() => {});
    setForm({ fullName: "", nationalId: "", phone: "", businessName: "", businessType: "", address: "", capital: "", notes: "" });
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="glass-card rounded-2xl overflow-hidden gold-border animate-fade-in">
        <div className="bg-primary/10 p-5 border-b border-border/30 flex items-center gap-3">
          <div className="bg-primary/20 p-2 rounded-lg"><Store className="h-6 w-6 text-primary" /></div>
          <div>
            <h1 className="font-heading text-xl font-black">طلب رخصة تجارية</h1>
            <p className="text-xs text-muted-foreground">قدّم طلب إصدار رخصة نشاط تجاري</p>
          </div>
        </div>
        <div className="p-6">
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label className="font-heading text-xs font-bold">الاسم الكامل *</Label>
                <Input value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} placeholder="أدخل الاسم الكامل" className="bg-secondary/50 border-border/50" />
              </div>
              <div className="space-y-2">
                <Label className="font-heading text-xs font-bold">اسم مستخدم Discord *</Label>
                <Input value={form.nationalId} onChange={(e) => setForm({ ...form, nationalId: e.target.value })} placeholder="أدخل اسم مستخدم Discord" className="bg-secondary/50 border-border/50" />
              </div>
            </div>
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label className="font-heading text-xs font-bold">رقم الجوال *</Label>
                <Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="05XXXXXXXX" className="bg-secondary/50 border-border/50" />
              </div>
              <div className="space-y-2">
                <Label className="font-heading text-xs font-bold">اسم النشاط التجاري *</Label>
                <Input value={form.businessName} onChange={(e) => setForm({ ...form, businessName: e.target.value })} placeholder="اسم المتجر أو الشركة" className="bg-secondary/50 border-border/50" />
              </div>
            </div>
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label className="font-heading text-xs font-bold">نوع النشاط *</Label>
                <Select value={form.businessType} onValueChange={(v) => setForm({ ...form, businessType: v })}>
                  <SelectTrigger className="bg-secondary/50 border-border/50"><SelectValue placeholder="اختر نوع النشاط" /></SelectTrigger>
                  <SelectContent>
                    {BUSINESS_TYPES.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="font-heading text-xs font-bold">رأس المال</Label>
                <Input value={form.capital} onChange={(e) => setForm({ ...form, capital: e.target.value })} placeholder="بالدولار" className="bg-secondary/50 border-border/50" />
              </div>
            </div>
            <div className="space-y-2">
              <Label className="font-heading text-xs font-bold">عنوان النشاط *</Label>
              <Input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} placeholder="المدينة، الحي، الشارع" className="bg-secondary/50 border-border/50" />
            </div>
            <div className="space-y-2">
              <Label className="font-heading text-xs font-bold">ملاحظات إضافية</Label>
              <Textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} placeholder="أي معلومات إضافية..." rows={4} className="bg-secondary/50 border-border/50" />
            </div>
            <Button type="submit" disabled={submitting} className="w-full gold-gradient text-primary-foreground font-heading font-bold hover:opacity-90 gold-glow h-11">
              <Send className="h-4 w-4 ml-2" />{submitting ? "جاري الإرسال..." : "إرسال الطلب"}
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}
