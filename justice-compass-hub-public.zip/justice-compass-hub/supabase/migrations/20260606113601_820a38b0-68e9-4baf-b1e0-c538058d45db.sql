
-- Staff: restrict reads to authenticated users
DROP POLICY IF EXISTS "Anyone can view staff" ON public.staff;
CREATE POLICY "Authenticated can view staff" ON public.staff
  FOR SELECT TO authenticated USING (true);

-- Archives: restrict reads to authenticated users
DROP POLICY IF EXISTS "Anyone can view archives" ON public.archives;
CREATE POLICY "Authenticated can view archives" ON public.archives
  FOR SELECT TO authenticated USING (true);

-- Budget: restrict reads to AG and Deputy AG only
DROP POLICY IF EXISTS "Authenticated can view budget" ON public.budget_items;
CREATE POLICY "AG and Deputy can view budget" ON public.budget_items
  FOR SELECT TO authenticated
  USING (has_role(auth.uid(), 'attorney_general'::app_role) OR has_role(auth.uid(), 'deputy_attorney_general'::app_role));

-- Photos storage: restrict INSERT/DELETE to judges+
DROP POLICY IF EXISTS "Authenticated can upload photos" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated can delete photos" ON storage.objects;
CREATE POLICY "Judges+ can upload photos" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id = 'photos' AND (
      has_role(auth.uid(), 'attorney_general'::app_role)
      OR has_role(auth.uid(), 'deputy_attorney_general'::app_role)
      OR has_role(auth.uid(), 'judge'::app_role)
    )
  );
CREATE POLICY "Judges+ can delete photos" ON storage.objects
  FOR DELETE TO authenticated
  USING (
    bucket_id = 'photos' AND (
      has_role(auth.uid(), 'attorney_general'::app_role)
      OR has_role(auth.uid(), 'deputy_attorney_general'::app_role)
      OR has_role(auth.uid(), 'judge'::app_role)
    )
  );

-- Revoke direct EXECUTE on SECURITY DEFINER helpers; RLS still uses them internally.
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, app_role) FROM anon, authenticated, PUBLIC;
DO $$ BEGIN
  IF EXISTS (SELECT 1 FROM pg_proc WHERE proname = 'find_user_by_email' AND pronamespace = 'public'::regnamespace) THEN
    EXECUTE 'REVOKE EXECUTE ON FUNCTION public.find_user_by_email(text) FROM anon, authenticated, PUBLIC';
  END IF;
END $$;
